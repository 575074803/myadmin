-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 
-- Database : myadmin
-- 
-- Part : #1
-- Date : 2018-01-18 10:35:21
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `sh_ad`
-- -----------------------------
DROP TABLE IF EXISTS `sh_ad`;
CREATE TABLE `sh_ad` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '信息id',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `classid` smallint(5) unsigned NOT NULL COMMENT '投放范围(广告位)',
  `parentid` smallint(5) unsigned NOT NULL COMMENT '所属广告位父id',
  `parentstr` varchar(80) NOT NULL COMMENT '所属广告位父id字符串',
  `title` varchar(30) NOT NULL COMMENT '广告标识',
  `admode` char(10) NOT NULL COMMENT '展示模式',
  `picurl` varchar(100) NOT NULL COMMENT '上传内容地址',
  `picurl2` varchar(100) NOT NULL,
  `adtext` text NOT NULL COMMENT '展示内容',
  `adtext2` text NOT NULL,
  `linkurl` varchar(255) NOT NULL COMMENT '跳转链接',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  `posttime` int(10) unsigned NOT NULL COMMENT '提交时间',
  `checkinfo` smallint(5) NOT NULL COMMENT '审核状态 1=显示，0=不显示',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=75 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_ad`
-- -----------------------------
INSERT INTO `sh_ad` VALUES ('71', '1', '1', '0', '', '111', '', '/uploads/20180109/0bd560ca4c82f8b56aceee28f3ecbb2e.png', '', '地方法', '', 'http://sccz.hzwzjs.net/', '1', '1535783820', '1');
INSERT INTO `sh_ad` VALUES ('72', '1', '1', '0', '', '商品', '', '/uploads/20180109/d8952126ec08c93d921eba1dbb769557.png', '', '11', '', 'http://sccz.hzwzjs.net/', '2', '1535786749', '1');
INSERT INTO `sh_ad` VALUES ('73', '1', '1', '0', '', '222', '', '/uploads/20180109/42fd6e7fed024664dbe24a4ac35b4c50.png', '', 'eee', '', 'http://sccz.hzwzjs.net/', '3', '1535787874', '1');
INSERT INTO `sh_ad` VALUES ('74', '7', '35', '0', '', '1111', '', '/uploads/20180110/747d0bc628f23ef0ad0feb74fbeea480.png', '', '1111', '', 'http://sccz.hzwzjs.net/', '4', '1538358230', '1');

-- -----------------------------
-- Table structure for `sh_admin`
-- -----------------------------
DROP TABLE IF EXISTS `sh_admin`;
CREATE TABLE `sh_admin` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '信息id',
  `username` varchar(30) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `nickname` char(32) NOT NULL COMMENT '昵称',
  `group_id` tinyint(1) unsigned NOT NULL COMMENT '级别',
  `loginip` char(20) NOT NULL COMMENT '登陆IP',
  `logintime` int(10) NOT NULL COMMENT '登陆时间 ',
  `is_open` tinyint(2) NOT NULL DEFAULT '1' COMMENT '审核状态 1=已开启，0=未开启',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_admin`
-- -----------------------------
INSERT INTO `sh_admin` VALUES ('1', 'saihucms', '450af3c223a5642981cd870285fc9948', '', '1', '127.0.0.1', '1516236744', '1');
INSERT INTO `sh_admin` VALUES ('2', 'tang', '450af3c223a5642981cd870285fc9948', '', '2', '127.0.0.1', '1508925621', '1');
INSERT INTO `sh_admin` VALUES ('3', 'test', '14e1b600b1fd579f47433b88e8d85291', '111', '2', '127.0.0.1', '1507219827', '1');
INSERT INTO `sh_admin` VALUES ('6', 'testpass', '450af3c223a5642981cd870285fc9948', '', '2', '127.0.0.1', '1507510077', '1');
INSERT INTO `sh_admin` VALUES ('7', 'gd', 'e33b52fbfbbaf1edbbf257d4a4ac0451', 'fdsfds', '3', '127.0.0.1', '1509066949', '1');

-- -----------------------------
-- Table structure for `sh_adtype`
-- -----------------------------
DROP TABLE IF EXISTS `sh_adtype`;
CREATE TABLE `sh_adtype` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '广告位id',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `parentid` smallint(5) unsigned NOT NULL COMMENT '上级id',
  `parentstr` varchar(50) NOT NULL COMMENT '上级id字符串',
  `classname` varchar(30) NOT NULL COMMENT '广告位名称',
  `width` smallint(5) unsigned NOT NULL COMMENT '广告位宽度',
  `height` smallint(5) unsigned NOT NULL COMMENT '广告位高度',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列顺序',
  `checkinfo` smallint(5) NOT NULL COMMENT '审核状态 1=显示，0=不显示',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_adtype`
-- -----------------------------
INSERT INTO `sh_adtype` VALUES ('1', '1', '0', '0', '幻灯片', '789', '324', '4', '1');
INSERT INTO `sh_adtype` VALUES ('28', '1', '0', '0', '手机端幻灯片', '640', '320', '5', '1');
INSERT INTO `sh_adtype` VALUES ('32', '1', '0', '0', '联系我们', '640', '440', '6', '1');
INSERT INTO `sh_adtype` VALUES ('33', '1', '0', '0', '平台介绍', '640', '440', '7', '1');
INSERT INTO `sh_adtype` VALUES ('34', '1', '0', '0', '英文广告位', '640', '440', '8', '1');
INSERT INTO `sh_adtype` VALUES ('35', '7', '0', '0', '英文广告2', '640', '440', '9', '1');

-- -----------------------------
-- Table structure for `sh_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `sh_auth_group`;
CREATE TABLE `sh_auth_group` (
  `group_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '全新ID',
  `title` char(100) NOT NULL DEFAULT '' COMMENT '标题',
  `status` tinyint(1) DEFAULT '0' COMMENT '状态 1=启用 0=禁用',
  `rules` longtext COMMENT '规则',
  `addtime` int(11) NOT NULL COMMENT '添加时间',
  `description` varchar(100) DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_auth_group`
-- -----------------------------
INSERT INTO `sh_auth_group` VALUES ('1', '超级管理员', '1', '1,2,289,288,291,292,293,15,16,119,120,121,17,149,116,117,118,18,108,114,112,301,3,5,126,127,128,4,230,232,129,189,190,193,192,295,241,243,244,246,7,309,310,311,312,313,27,29,163,294,38,167,182,169,28,48,315,297,305,306,307,308,31,32,249,251,46,176,183,178,314,45,170,171,173,196,197,202,252,254,290,203,205,204,257,272,206,207,212,208,213,258,262,321,209,215,214,263,210,217,216,264,211,266,267,269', '1465114224', '');
INSERT INTO `sh_auth_group` VALUES ('2', '管理员', '1', '1,2,270,3,4,129,230,232,5,126,127,128,7,9,13,14,236,237,235,238,15,16,121,145,17,116,117,118,149,151,181,18,108,109,110,111,112,114,189,190,192,193,241,196,197,252,198,202,253,254,255,203,204,205,257,272', '1465114224', '');
INSERT INTO `sh_auth_group` VALUES ('3', '商品管理员', '1', '1,2,289,288,291,292,293,15,16,119,120,121,145,17,149,116,117,118,181,18,108,114,112,27,29,161,163,164,162,38,167,182,169,166,28,48,31,32,249,250,251,46,176,183,178,45,170,171,173', '1465114224', '');

-- -----------------------------
-- Table structure for `sh_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `sh_auth_rule`;
CREATE TABLE `sh_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `href` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '暂弃',
  `authopen` tinyint(2) NOT NULL DEFAULT '1' COMMENT '0=需要验证 1=无需验证',
  `icon` varchar(20) DEFAULT NULL COMMENT '样式',
  `condition` char(100) DEFAULT '',
  `pid` int(5) NOT NULL DEFAULT '0' COMMENT '父栏目ID',
  `pidstr` varchar(255) NOT NULL COMMENT '父id 集合',
  `orderid` int(11) DEFAULT '0' COMMENT '排序',
  `addtime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `menustatus` tinyint(1) DEFAULT NULL COMMENT '1=显示状态 0=隐藏状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=325 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_auth_rule`
-- -----------------------------
INSERT INTO `sh_auth_rule` VALUES ('1', 'System', '系统设置', '1', '1', '0', 'home', '', '0', '0', '0', '1446535750', '1');
INSERT INTO `sh_auth_rule` VALUES ('2', 'System/system', '系统设置', '1', '1', '0', '', '', '1', '0,1', '3', '1446535789', '1');
INSERT INTO `sh_auth_rule` VALUES ('3', 'Databackup/index', '数据库管理', '1', '1', '0', 'database', '', '0', '0', '2', '1446535805', '1');
INSERT INTO `sh_auth_rule` VALUES ('4', 'Databackup/importlist', '备份管理', '1', '1', '0', '', '', '3', '0,3', '10', '1446535750', '1');
INSERT INTO `sh_auth_rule` VALUES ('5', 'Databackup/index', '数据库', '1', '1', '0', '', '', '3', '0,3', '1', '1446535834', '1');
INSERT INTO `sh_auth_rule` VALUES ('313', 'category/all_del', '操作-多选删除', '1', '1', '1', '', '', '309', '0,7,309', '74', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('15', 'Auth/admin_list', '权限管理', '1', '1', '0', 'futbol-o', '', '0', '0', '1', '1446535750', '1');
INSERT INTO `sh_auth_rule` VALUES ('16', 'Auth/admin_list', '管理员列表', '1', '1', '0', '', '', '15', '0,15', '0', '1446535750', '1');
INSERT INTO `sh_auth_rule` VALUES ('17', 'Auth/admin_group', '用户组列表', '1', '1', '0', '', '', '15', '0,15', '1', '1446535750', '1');
INSERT INTO `sh_auth_rule` VALUES ('18', 'Auth/admin_rule', '权限管理', '1', '1', '0', '', '', '15', '0,15', '2', '1446535750', '1');
INSERT INTO `sh_auth_rule` VALUES ('27', 'Users', '会员管理', '1', '1', '0', 'user', '', '0', '0', '5', '1447231507', '1');
INSERT INTO `sh_auth_rule` VALUES ('28', 'Function', '网站功能', '1', '1', '0', 'cog', '', '0', '0', '6', '1447231590', '1');
INSERT INTO `sh_auth_rule` VALUES ('29', 'Users/index', '会员列表', '1', '1', '0', '', '', '27', '0,27', '10', '1447232085', '1');
INSERT INTO `sh_auth_rule` VALUES ('31', 'Link/index', '友情链接', '1', '1', '0', '', '', '28', '0,28', '3', '1447232183', '1');
INSERT INTO `sh_auth_rule` VALUES ('32', 'Link/add', '操作-添加', '1', '1', '0', '', '', '31', '0,28,31', '1', '1447639935', '0');
INSERT INTO `sh_auth_rule` VALUES ('38', 'Users/user_group', '会员组', '1', '1', '0', '', '', '27', '0,27', '50', '1448413248', '1');
INSERT INTO `sh_auth_rule` VALUES ('45', 'Ad/index', '广告管理', '1', '1', '0', '', '', '28', '0,28', '5', '1450314297', '1');
INSERT INTO `sh_auth_rule` VALUES ('46', 'Ad/type', '广告位管理', '1', '1', '0', '', '', '28', '0,28', '4', '1450314324', '1');
INSERT INTO `sh_auth_rule` VALUES ('48', 'Message/index', '留言管理', '1', '1', '0', '', '', '28', '0,28', '1', '1451267354', '1');
INSERT INTO `sh_auth_rule` VALUES ('108', 'Auth/rule_add', '操作-添加', '1', '1', '0', '', '', '18', '0,15,18', '0', '1461550835', '0');
INSERT INTO `sh_auth_rule` VALUES ('306', 'Link/type_edit', '操作-修改', '1', '1', '1', '', '', '297', '0,28,297', '67', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('301', 'Auth/rule_all_del', '操作-群体删除', '1', '1', '0', '', '', '18', '0,15,18', '62', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('112', 'Auth/rule_del', '操作-删除', '1', '1', '0', '', '', '18', '0,15,18', '4', '1461551536', '0');
INSERT INTO `sh_auth_rule` VALUES ('114', 'Auth/rule_edit', '操作-修改', '1', '1', '0', '', '', '18', '0,15,18', '2', '1461551913', '0');
INSERT INTO `sh_auth_rule` VALUES ('116', 'Auth/group_edit', '操作-修改', '1', '1', '0', '', '', '17', '0,15,17', '3', '1461552326', '0');
INSERT INTO `sh_auth_rule` VALUES ('117', 'Auth/group_del', '操作-删除', '1', '1', '0', '', '', '17', '0,15,17', '30', '1461552349', '0');
INSERT INTO `sh_auth_rule` VALUES ('118', 'Auth/group_access', '操作-权限', '1', '1', '0', '', '', '17', '0,15,17', '40', '1461552404', '0');
INSERT INTO `sh_auth_rule` VALUES ('119', 'Auth/admin_add', '操作-添加', '1', '1', '0', '', '', '16', '0,15,16', '0', '1461553162', '0');
INSERT INTO `sh_auth_rule` VALUES ('120', 'Auth/admin_edit', '操作-修改', '1', '1', '0', '', '', '16', '0,15,16', '2', '1461554130', '0');
INSERT INTO `sh_auth_rule` VALUES ('121', 'Auth/admin_del', '操作-删除', '1', '1', '0', '', '', '16', '0,15,16', '4', '1461554152', '0');
INSERT INTO `sh_auth_rule` VALUES ('126', 'Databackup/export', '数据库备份', '1', '1', '0', '', '', '5', '0,3,5', '1', '1461550835', '0');
INSERT INTO `sh_auth_rule` VALUES ('127', 'Databackup/optimize', '数据库优化', '1', '1', '0', '', '', '5', '0,3,5', '1', '1461550835', '0');
INSERT INTO `sh_auth_rule` VALUES ('128', 'Databackup/repair', '数据库修复', '1', '1', '0', '', '', '5', '0,3,5', '1', '1461550835', '0');
INSERT INTO `sh_auth_rule` VALUES ('129', 'Databackup/del', '数据库备份删除', '1', '1', '0', '', '', '4', '0,3,4', '3', '1461550835', '0');
INSERT INTO `sh_auth_rule` VALUES ('310', 'Category/add', '操作-添加', '1', '1', '1', '', '', '309', '0,7,309', '71', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('230', 'Databackup/import', '数据库备份还原', '1', '1', '0', '', '', '4', '0,3,4', '1', '1497423595', '0');
INSERT INTO `sh_auth_rule` VALUES ('149', 'Auth/group_add', '操作-添加', '1', '1', '0', '', '', '17', '0,15,17', '1', '1461550835', '0');
INSERT INTO `sh_auth_rule` VALUES ('312', 'Category/del', '操作-删除', '1', '1', '1', '', '', '309', '0,7,309', '73', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('294', 'users/add', '操作-添加', '1', '1', '0', '', '', '29', '0,27,29', '57', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('309', 'Category/index', '栏目列表', '1', '1', '0', '', '', '7', '0,7', '70', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('324', 'Wechat/images_del', '操作-添加', '1', '1', '0', '', '', '266', '0,206,266', '80', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('163', 'Users/edit', '操作-编辑', '1', '1', '0', '', '', '29', '0,27,29', '2', '1461550835', '0');
INSERT INTO `sh_auth_rule` VALUES ('315', 'Message/edit', '操作-回复', '1', '1', '0', '', '', '48', '0,28,48', '76', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('167', 'Users/group_add', '操作-添加', '1', '1', '0', '', '', '38', '0,27,38', '10', '1461550835', '0');
INSERT INTO `sh_auth_rule` VALUES ('169', 'Users/group_del', '操作-删除', '1', '1', '0', '', '', '38', '0,27,38', '30', '1461550835', '0');
INSERT INTO `sh_auth_rule` VALUES ('170', 'Ad/add', '操作-添加', '1', '1', '0', '', '', '45', '0,28,45', '1', '1461550835', '0');
INSERT INTO `sh_auth_rule` VALUES ('171', 'Ad/edit', '操作-修改', '1', '1', '0', '', '', '45', '0,28,45', '2', '1461550835', '0');
INSERT INTO `sh_auth_rule` VALUES ('173', 'Ad/del', '操作-删除', '1', '1', '0', '', '', '45', '0,28,45', '5', '1461550835', '0');
INSERT INTO `sh_auth_rule` VALUES ('176', 'Ad/type_add', '操作-添加', '1', '1', '0', '', '', '46', '0,28,46', '1', '1461550835', '0');
INSERT INTO `sh_auth_rule` VALUES ('252', 'Template/edit', '操作-编辑', '1', '1', '0', '', '', '197', '0,196,197', '3', '1497428906', '0');
INSERT INTO `sh_auth_rule` VALUES ('178', 'Ad/type_del', '操作-删除', '1', '1', '0', '', '', '46', '0,28,46', '4', '1461550835', '0');
INSERT INTO `sh_auth_rule` VALUES ('314', 'Ad/type_all_del', '操作-多选删除', '1', '1', '0', '', '', '46', '0,28,46', '75', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('323', 'Wechat/images_edit', '操作-修改', '1', '1', '0', '', '', '266', '0,206,266', '79', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('182', 'Users/group_edit', '操作-修改', '1', '1', '0', '', '', '38', '0,27,38', '15', '1461834780', '0');
INSERT INTO `sh_auth_rule` VALUES ('183', 'Ad/type_edit', '操作-修改', '1', '1', '0', '', '', '46', '0,28,46', '2', '1461834988', '0');
INSERT INTO `sh_auth_rule` VALUES ('189', 'Module', '模型管理', '1', '1', '0', 'cubes', '', '0', '0', '3', '1466825363', '1');
INSERT INTO `sh_auth_rule` VALUES ('190', 'Module/index', '模型列表', '1', '1', '0', '', '', '189', '0,189', '1', '1466826681', '1');
INSERT INTO `sh_auth_rule` VALUES ('192', 'Module/edit', '操作-修改', '1', '1', '0', '', '', '190', '0,189,190', '2', '1467007920', '0');
INSERT INTO `sh_auth_rule` VALUES ('193', 'Module/add', '操作-添加', '1', '1', '0', '', '', '190', '0,189,190', '1', '1467007955', '0');
INSERT INTO `sh_auth_rule` VALUES ('196', 'Template', '模版管理', '1', '1', '0', 'code', '', '0', '0', '7', '1481857304', '1');
INSERT INTO `sh_auth_rule` VALUES ('197', 'Template/index', '模版管理', '1', '1', '0', '', '', '196', '0,196', '1', '1481857540', '1');
INSERT INTO `sh_auth_rule` VALUES ('293', 'System/site_del', '删除站点', '1', '1', '0', '', '', '288', '0,1,288', '16', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('202', 'Template/add', '操作-添加', '1', '1', '0', '', '', '197', '0,196,197', '1', '1481859447', '0');
INSERT INTO `sh_auth_rule` VALUES ('203', 'Debris/index', '碎片管理', '1', '1', '0', '', '', '196', '0,196', '2', '1484797759', '1');
INSERT INTO `sh_auth_rule` VALUES ('204', 'Debris/edit', '操作-编辑', '1', '1', '0', '', '', '203', '0,196,203', '2', '1484797849', '0');
INSERT INTO `sh_auth_rule` VALUES ('205', 'Debris/add', '操作-添加', '1', '1', '0', '', '', '203', '0,196,203', '1', '1484797878', '0');
INSERT INTO `sh_auth_rule` VALUES ('206', 'Wechat', '微信管理', '1', '1', '0', 'comments', '', '0', '0', '8', '1487063570', '1');
INSERT INTO `sh_auth_rule` VALUES ('207', 'Wechat/index', '公众号管理', '1', '1', '0', '', '', '206', '0,206', '1', '1487063705', '1');
INSERT INTO `sh_auth_rule` VALUES ('208', 'Wechat/menu', '菜单管理', '1', '1', '0', '', '', '206', '0,206', '2', '1487063765', '1');
INSERT INTO `sh_auth_rule` VALUES ('209', 'Wechat/text', '文本回复', '1', '1', '0', '', '', '206', '0,206', '3', '1487063834', '1');
INSERT INTO `sh_auth_rule` VALUES ('210', 'Wechat/img', '图文回复', '1', '1', '0', '', '', '206', '0,206', '4', '1487063858', '1');
INSERT INTO `sh_auth_rule` VALUES ('212', 'Wechat/weixin', '操作-设置', '1', '1', '0', '', '', '207', '0,206,207', '1', '1487064541', '0');
INSERT INTO `sh_auth_rule` VALUES ('213', 'Wechat/menu_add', '操作-添加', '1', '1', '0', '', '', '208', '0,206,208', '1', '1487149151', '0');
INSERT INTO `sh_auth_rule` VALUES ('214', 'Wechat/text_edit', '操作-编辑', '1', '1', '0', '', '', '209', '0,206,209', '2', '1487233984', '0');
INSERT INTO `sh_auth_rule` VALUES ('215', 'Wechat/text_add', '操作-添加', '1', '1', '0', '', '', '209', '0,206,209', '1', '1487234062', '0');
INSERT INTO `sh_auth_rule` VALUES ('216', 'Wechat/img_edit', '操作-编辑', '1', '1', '0', '', '', '210', '0,206,210', '2', '1487318148', '0');
INSERT INTO `sh_auth_rule` VALUES ('217', 'Wechat/img_add', '操作-添加', '1', '1', '0', '', '', '210', '0,206,210', '1', '1487318175', '0');
INSERT INTO `sh_auth_rule` VALUES ('232', 'Database/downFile', '操作-下载', '1', '1', '0', '', '', '4', '0,3,4', '2', '1497423744', '0');
INSERT INTO `sh_auth_rule` VALUES ('311', 'Category/edit', '操作-修改', '1', '1', '1', '', '', '309', '0,7,309', '72', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('241', 'Module/field', '模型字段', '1', '1', '0', '', '', '190', '0,189,190', '6', '1497425972', '0');
INSERT INTO `sh_auth_rule` VALUES ('243', 'Module/field_add', '操作-添加', '1', '1', '0', '', '', '241', '0,189,190,241', '1', '1497426089', '0');
INSERT INTO `sh_auth_rule` VALUES ('244', 'Module/field_edit', '操作-修改', '1', '1', '0', '', '', '241', '0,189,190,241', '2', '1497426134', '0');
INSERT INTO `sh_auth_rule` VALUES ('246', 'Module/field_del', '操作-删除', '1', '1', '0', '', '', '241', '0,189,190,241', '5', '1497426241', '0');
INSERT INTO `sh_auth_rule` VALUES ('249', 'Link/edit', '操作-编辑', '1', '1', '0', '', '', '31', '0,28,31', '2', '1497427694', '0');
INSERT INTO `sh_auth_rule` VALUES ('251', 'Link/del', '操作-删除', '1', '1', '0', '', '', '31', '0,28,31', '4', '1497427780', '0');
INSERT INTO `sh_auth_rule` VALUES ('292', 'System/site_update', '修改站点', '1', '1', '0', '', '', '288', '0,1,288', '15', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('254', 'Template/delete', '操作-删除', '1', '1', '0', '', '', '197', '0,196,197', '5', '1497429018', '0');
INSERT INTO `sh_auth_rule` VALUES ('290', 'Template/edit_all', '替换所有模板', '1', '1', '0', '', '', '197', '0,196,197', '53', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('291', 'System/site_add', '新增站点', '1', '1', '0', '', '', '288', '0,1,288', '6', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('257', 'Debris/del', '操作-删除', '1', '1', '0', '', '', '203', '0,196,203', '3', '1497429416', '0');
INSERT INTO `sh_auth_rule` VALUES ('258', 'Wechat/menu_edit', '操作-编辑', '1', '1', '0', '', '', '208', '0,206,208', '2', '1497429671', '0');
INSERT INTO `sh_auth_rule` VALUES ('322', 'Wechat/images_add', '操作-添加', '1', '1', '0', '', '', '266', '0,206,266', '78', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('321', 'Wechat/menu_del', '操作-删除', '1', '1', '0', '', '', '208', '0,206,208', '77', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('262', 'Wechat/menu_create', '操作-生成菜单', '1', '1', '0', '', '', '208', '0,206,208', '6', '1497429886', '0');
INSERT INTO `sh_auth_rule` VALUES ('263', 'Wechat/text_del', '操作-删除', '1', '1', '0', '', '', '209', '0,206,209', '3', '1497430020', '0');
INSERT INTO `sh_auth_rule` VALUES ('264', 'Wechat/img_del', '操作-删除', '1', '1', '0', '', '', '210', '0,206,210', '3', '1497430159', '0');
INSERT INTO `sh_auth_rule` VALUES ('305', 'Link/type_add', '操作-添加', '1', '1', '1', '', '', '297', '0,28,297', '66', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('266', 'Wechat/images', '多图文回复', '1', '1', '0', '', '', '206', '0,206', '7', '1501221710', '0');
INSERT INTO `sh_auth_rule` VALUES ('267', 'Plugin/index', '插件管理', '1', '1', '1', 'plug', '', '0', '0', '8', '1501466560', '0');
INSERT INTO `sh_auth_rule` VALUES ('269', 'Plugin/login', '登录插件', '1', '1', '1', '', '', '267', '0,267', '1', '1501466732', '1');
INSERT INTO `sh_auth_rule` VALUES ('288', 'System/site', '站点设置', '1', '1', '0', '', '', '1', '0,1', '5', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('272', 'Debris/type', '碎片分类', '1', '1', '1', '', '', '196', '0,196', '3', '1504082720', '1');
INSERT INTO `sh_auth_rule` VALUES ('289', 'System/add_system', '增加新变量', '1', '1', '0', '', '', '2', '0,1,2', '4', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('295', 'module/del', '操作-删除', '1', '1', '1', '', '', '190', '0,189,190', '3', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('7', 'Category', '栏目管理', '1', '1', '0', 'navicon', '', '0', '0', '4', '1446535875', '1');
INSERT INTO `sh_auth_rule` VALUES ('297', 'Link/type', '友情链接类别', '1', '1', '0', '', '', '28', '0,28', '2', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('307', 'Link/type_del', '操作-删除', '1', '1', '1', '', '', '297', '0,28,297', '68', '0', '1');
INSERT INTO `sh_auth_rule` VALUES ('308', 'Link/type_all_del', '操作-多选删除', '1', '1', '1', '', '', '297', '0,28,297', '69', '0', '1');

-- -----------------------------
-- Table structure for `sh_cascadedata`
-- -----------------------------
DROP TABLE IF EXISTS `sh_cascadedata`;
CREATE TABLE `sh_cascadedata` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '级联数据id',
  `dataname` char(30) NOT NULL COMMENT '级联数据名称',
  `datavalue` char(20) NOT NULL COMMENT '级联数据值',
  `datagroup` char(20) NOT NULL COMMENT '所属级联组',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  `level` tinyint(1) unsigned NOT NULL COMMENT '级联数据层次',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20020 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_cascadedata`
-- -----------------------------
INSERT INTO `sh_cascadedata` VALUES ('20019', '澳门特别行政区', '17500', 'area', '17500', '0');
INSERT INTO `sh_cascadedata` VALUES ('20018', '香港特别行政区', '17000', 'area', '17000', '0');
INSERT INTO `sh_cascadedata` VALUES ('20017', '台湾省', '16500', 'area', '16500', '0');
INSERT INTO `sh_cascadedata` VALUES ('20016', '图木舒克市', '16015.3', 'area', '16015', '2');
INSERT INTO `sh_cascadedata` VALUES ('20015', '阿拉尔市', '16015.2', 'area', '16015', '2');
INSERT INTO `sh_cascadedata` VALUES ('20014', '石河子市', '16015.1', 'area', '16015', '2');
INSERT INTO `sh_cascadedata` VALUES ('20013', '省直辖行政单位', '16015', 'area', '16015', '1');
INSERT INTO `sh_cascadedata` VALUES ('20012', '吉木乃县', '16014.7', 'area', '16015', '2');
INSERT INTO `sh_cascadedata` VALUES ('20011', '青河县', '16014.6', 'area', '16015', '2');
INSERT INTO `sh_cascadedata` VALUES ('20010', '哈巴河县', '16014.5', 'area', '16015', '2');
INSERT INTO `sh_cascadedata` VALUES ('20009', '福海县', '16014.4', 'area', '16014', '2');
INSERT INTO `sh_cascadedata` VALUES ('20008', '富蕴县', '16014.3', 'area', '16014', '2');
INSERT INTO `sh_cascadedata` VALUES ('20007', '布尔津县', '16014.2', 'area', '16014', '2');
INSERT INTO `sh_cascadedata` VALUES ('20006', '阿勒泰市', '16014.1', 'area', '16014', '2');
INSERT INTO `sh_cascadedata` VALUES ('20005', '阿勒泰地区', '16014', 'area', '16014', '1');
INSERT INTO `sh_cascadedata` VALUES ('20004', '和布克赛尔蒙古自治县', '16013.7', 'area', '16014', '2');
INSERT INTO `sh_cascadedata` VALUES ('20003', '裕民县', '16013.6', 'area', '16014', '2');
INSERT INTO `sh_cascadedata` VALUES ('20002', '托里县', '16013.5', 'area', '16014', '2');
INSERT INTO `sh_cascadedata` VALUES ('20001', '沙湾县', '16013.4', 'area', '16013', '2');
INSERT INTO `sh_cascadedata` VALUES ('20000', '额敏县', '16013.3', 'area', '16013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19999', '乌苏市', '16013.2', 'area', '16013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19998', '塔城市', '16013.1', 'area', '16013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19997', '塔城地区', '16013', 'area', '16013', '1');
INSERT INTO `sh_cascadedata` VALUES ('19996', '尼勒克县', '16012.10', 'area', '16012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19995', '特克斯县', '16012.9', 'area', '16013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19994', '昭苏县', '16012.8', 'area', '16013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19993', '新源县', '16012.7', 'area', '16013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19992', '巩留县', '16012.6', 'area', '16013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19991', '霍城县', '16012.5', 'area', '16013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19990', '察布查尔锡伯自治县', '16012.4', 'area', '16012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19989', '伊宁县', '16012.3', 'area', '16012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19988', '奎屯市', '16012.2', 'area', '16012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19987', '伊宁市', '16012.1', 'area', '16012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19986', '伊犁哈萨克自治州', '16012', 'area', '16012', '1');
INSERT INTO `sh_cascadedata` VALUES ('19985', '民丰县', '16011.8', 'area', '16012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19984', '于田县', '16011.7', 'area', '16012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19983', '策勒县', '16011.6', 'area', '16012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19982', '洛浦县', '16011.5', 'area', '16012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19981', '皮山县', '16011.4', 'area', '16011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19980', '墨玉县', '16011.3', 'area', '16011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19979', '和田县', '16011.2', 'area', '16011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19978', '和田市', '16011.1', 'area', '16011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19977', '和田地区', '16011', 'area', '16011', '1');
INSERT INTO `sh_cascadedata` VALUES ('19976', '塔什库尔干塔吉克自治县', '16010.12', 'area', '16010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19975', '巴楚县', '16010.11', 'area', '16010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19974', '伽师县', '16010.10', 'area', '16010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19973', '岳普湖县', '16010.9', 'area', '16011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19972', '麦盖提县', '16010.8', 'area', '16011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19971', '叶城县', '16010.7', 'area', '16011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19970', '莎车县', '16010.6', 'area', '16011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19969', '泽普县', '16010.5', 'area', '16011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19968', '英吉沙县', '16010.4', 'area', '16010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19967', '疏勒县', '16010.3', 'area', '16010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19966', '疏附县', '16010.2', 'area', '16010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19965', '喀什市', '16010.1', 'area', '16010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19964', '喀什地区', '16010', 'area', '16010', '1');
INSERT INTO `sh_cascadedata` VALUES ('19963', '乌恰县', '16009.4', 'area', '16009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19962', '阿合奇县', '16009.3', 'area', '16009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19961', '阿克陶县', '16009.2', 'area', '16009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19960', '阿图什市', '16009.1', 'area', '16009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19959', '克孜勒苏柯尔克孜自治州', '16009', 'area', '16009', '1');
INSERT INTO `sh_cascadedata` VALUES ('19958', '柯坪县', '16008.9', 'area', '16009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19957', '阿瓦提县', '16008.8', 'area', '16009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19956', '乌什县', '16008.7', 'area', '16009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19955', '拜城县', '16008.6', 'area', '16009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19954', '新和县', '16008.5', 'area', '16009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19953', '沙雅县', '16008.4', 'area', '16008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19952', '库车县', '16008.3', 'area', '16008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19951', '温宿县', '16008.2', 'area', '16008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19950', '阿克苏市', '16008.1', 'area', '16008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19949', '阿克苏地区', '16008', 'area', '16008', '1');
INSERT INTO `sh_cascadedata` VALUES ('19948', '博湖县', '16007.9', 'area', '16008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19947', '和硕县', '16007.8', 'area', '16008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19946', '和静县', '16007.7', 'area', '16008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19945', '焉耆回族自治县', '16007.6', 'area', '16008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19944', '且末县', '16007.5', 'area', '16008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19943', '若羌县', '16007.4', 'area', '16007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19942', '尉犁县', '16007.3', 'area', '16007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19941', '轮台县', '16007.2', 'area', '16007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19940', '库尔勒市', '16007.1', 'area', '16007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19939', '巴音郭楞蒙古自治州', '16007', 'area', '16007', '1');
INSERT INTO `sh_cascadedata` VALUES ('19938', '温泉县', '16006.3', 'area', '16006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19937', '精河县', '16006.2', 'area', '16006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19936', '博乐市', '16006.1', 'area', '16006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19935', '博尔塔拉蒙古自治州', '16006', 'area', '16006', '1');
INSERT INTO `sh_cascadedata` VALUES ('19934', '木垒哈萨克自治县', '16005.8', 'area', '16006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19933', '吉木萨尔县', '16005.7', 'area', '16006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19932', '奇台县', '16005.6', 'area', '16006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19931', '玛纳斯县', '16005.5', 'area', '16006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19930', '呼图壁县', '16005.4', 'area', '16005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19929', '米泉市', '16005.3', 'area', '16005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19928', '阜康市', '16005.2', 'area', '16005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19927', '昌吉市', '16005.1', 'area', '16005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19926', '昌吉回族自治州', '16005', 'area', '16005', '1');
INSERT INTO `sh_cascadedata` VALUES ('19925', '伊吾县', '16004.3', 'area', '16004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19924', '巴里坤哈萨克自治县', '16004.2', 'area', '16004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19923', '哈密市', '16004.1', 'area', '16004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19922', '哈密地区', '16004', 'area', '16004', '1');
INSERT INTO `sh_cascadedata` VALUES ('19921', '托克逊县', '16003.3', 'area', '16003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19920', '鄯善县', '16003.2', 'area', '16003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19919', '吐鲁番市', '16003.1', 'area', '16003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19918', '吐鲁番地区', '16003', 'area', '16003', '1');
INSERT INTO `sh_cascadedata` VALUES ('19917', '乌尔禾区', '16002.4', 'area', '16002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19916', '白碱滩区', '16002.3', 'area', '16002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19915', '克拉玛依区', '16002.2', 'area', '16002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19914', '独山子区', '16002.1', 'area', '16002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19913', '克拉玛依市', '16002', 'area', '16002', '1');
INSERT INTO `sh_cascadedata` VALUES ('19912', '乌鲁木齐县', '16001.8', 'area', '16002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19911', '东山区', '16001.7', 'area', '16002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19910', '达坂城区', '16001.6', 'area', '16002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19909', '头屯河区', '16001.5', 'area', '16002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19908', '水磨沟区', '16001.4', 'area', '16001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19907', '新市区', '16001.3', 'area', '16001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19906', '沙依巴克区', '16001.2', 'area', '16001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19905', '天山区', '16001.1', 'area', '16001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19904', '乌鲁木齐市', '16001', 'area', '16001', '1');
INSERT INTO `sh_cascadedata` VALUES ('19903', '新疆维吾尔自治区', '16000', 'area', '16000', '0');
INSERT INTO `sh_cascadedata` VALUES ('19902', '海原县', '15505.3', 'area', '15505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19901', '中宁县', '15505.2', 'area', '15505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19900', '沙坡头区', '15505.1', 'area', '15505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19899', '中卫市', '15505', 'area', '15505', '1');
INSERT INTO `sh_cascadedata` VALUES ('19898', '彭阳县', '15504.5', 'area', '15505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19897', '泾源县', '15504.4', 'area', '15504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19896', '隆德县', '15504.3', 'area', '15504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19895', '西吉县', '15504.2', 'area', '15504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19894', '原州区', '15504.1', 'area', '15504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19893', '固原市', '15504', 'area', '15504', '1');
INSERT INTO `sh_cascadedata` VALUES ('19892', '青铜峡市', '15503.4', 'area', '15503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19891', '同心县', '15503.3', 'area', '15503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19890', '盐池县', '15503.2', 'area', '15503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19889', '利通区', '15503.1', 'area', '15503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19888', '吴忠市', '15503', 'area', '15503', '1');
INSERT INTO `sh_cascadedata` VALUES ('19887', '平罗县', '15502.3', 'area', '15502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19886', '惠农区', '15502.2', 'area', '15502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19885', '大武口区', '15502.1', 'area', '15502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19884', '石嘴山市', '15502', 'area', '15502', '1');
INSERT INTO `sh_cascadedata` VALUES ('19883', '灵武市', '15501.6', 'area', '15502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19882', '贺兰县', '15501.5', 'area', '15502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19881', '永宁县', '15501.4', 'area', '15501', '2');
INSERT INTO `sh_cascadedata` VALUES ('19880', '金凤区', '15501.3', 'area', '15501', '2');
INSERT INTO `sh_cascadedata` VALUES ('19879', '西夏区', '15501.2', 'area', '15501', '2');
INSERT INTO `sh_cascadedata` VALUES ('19878', '兴庆区', '15501.1', 'area', '15501', '2');
INSERT INTO `sh_cascadedata` VALUES ('19877', '银川市', '15501', 'area', '15501', '1');
INSERT INTO `sh_cascadedata` VALUES ('19876', '宁夏回族自治区', '15500', 'area', '15500', '0');
INSERT INTO `sh_cascadedata` VALUES ('19875', '天峻县', '15008.5', 'area', '15009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19874', '都兰县', '15008.4', 'area', '15008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19873', '乌兰县', '15008.3', 'area', '15008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19872', '德令哈市', '15008.2', 'area', '15008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19871', '格尔木市', '15008.1', 'area', '15008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19870', '海西蒙古族藏族自治州', '15008', 'area', '15008', '1');
INSERT INTO `sh_cascadedata` VALUES ('19869', '曲麻莱县', '15007.6', 'area', '15008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19868', '囊谦县', '15007.5', 'area', '15008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19867', '治多县', '15007.4', 'area', '15007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19866', '称多县', '15007.3', 'area', '15007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19865', '杂多县', '15007.2', 'area', '15007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19864', '玉树县', '15007.1', 'area', '15007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19863', '玉树藏族自治州', '15007', 'area', '15007', '1');
INSERT INTO `sh_cascadedata` VALUES ('19862', '玛多县', '15006.6', 'area', '15007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19861', '久治县', '15006.5', 'area', '15007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19860', '达日县', '15006.4', 'area', '15006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19859', '甘德县', '15006.3', 'area', '15006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19858', '班玛县', '15006.2', 'area', '15006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19857', '玛沁县', '15006.1', 'area', '15006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19856', '果洛藏族自治州', '15006', 'area', '15006', '1');
INSERT INTO `sh_cascadedata` VALUES ('19855', '贵南县', '15005.5', 'area', '15006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19854', '兴海县', '15005.4', 'area', '15005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19853', '贵德县', '15005.3', 'area', '15005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19852', '同德县', '15005.2', 'area', '15005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19851', '共和县', '15005.1', 'area', '15005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19850', '海南藏族自治州', '15005', 'area', '15005', '1');
INSERT INTO `sh_cascadedata` VALUES ('19849', '河南蒙古族自治县', '15004.4', 'area', '15004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19848', '泽库县', '15004.3', 'area', '15004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19847', '尖扎县', '15004.2', 'area', '15004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19846', '同仁县', '15004.1', 'area', '15004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19845', '黄南藏族自治州', '15004', 'area', '15004', '1');
INSERT INTO `sh_cascadedata` VALUES ('19844', '刚察县', '15003.4', 'area', '15003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19843', '海晏县', '15003.3', 'area', '15003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19842', '祁连县', '15003.2', 'area', '15003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19841', '门源回族自治县', '15003.1', 'area', '15003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19840', '海北藏族自治州', '15003', 'area', '15003', '1');
INSERT INTO `sh_cascadedata` VALUES ('19839', '循化撒拉族自治县', '15002.6', 'area', '15003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19838', '化隆回族自治县', '15002.5', 'area', '15003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19837', '互助土族自治县', '15002.4', 'area', '15002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19836', '乐都县', '15002.3', 'area', '15002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19835', '民和回族土族自治县', '15002.2', 'area', '15002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19834', '平安县', '15002.1', 'area', '15002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19833', '海东地区', '15002', 'area', '15002', '1');
INSERT INTO `sh_cascadedata` VALUES ('19832', '湟源县', '15001.7', 'area', '15002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19831', '湟中县', '15001.6', 'area', '15002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19830', '大通回族土族自治县', '15001.5', 'area', '15002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19829', '城北区', '15001.4', 'area', '15001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19828', '城西区', '15001.3', 'area', '15001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19827', '城中区', '15001.2', 'area', '15001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19826', '城东区', '15001.1', 'area', '15001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19825', '西宁市', '15001', 'area', '15001', '1');
INSERT INTO `sh_cascadedata` VALUES ('19824', '青海省', '15000', 'area', '15000', '0');
INSERT INTO `sh_cascadedata` VALUES ('19823', '夏河县', '14514.8', 'area', '14515', '2');
INSERT INTO `sh_cascadedata` VALUES ('19822', '碌曲县', '14514.7', 'area', '14515', '2');
INSERT INTO `sh_cascadedata` VALUES ('19821', '玛曲县', '14514.6', 'area', '14515', '2');
INSERT INTO `sh_cascadedata` VALUES ('19820', '迭部县', '14514.5', 'area', '14515', '2');
INSERT INTO `sh_cascadedata` VALUES ('19819', '舟曲县', '14514.4', 'area', '14514', '2');
INSERT INTO `sh_cascadedata` VALUES ('19818', '卓尼县', '14514.3', 'area', '14514', '2');
INSERT INTO `sh_cascadedata` VALUES ('19817', '临潭县', '14514.2', 'area', '14514', '2');
INSERT INTO `sh_cascadedata` VALUES ('19816', '合作市', '14514.1', 'area', '14514', '2');
INSERT INTO `sh_cascadedata` VALUES ('19815', '甘南藏族自治州', '14514', 'area', '14514', '1');
INSERT INTO `sh_cascadedata` VALUES ('19814', '积石山保安族东乡族撒拉族自治县', '14513.8', 'area', '14514', '2');
INSERT INTO `sh_cascadedata` VALUES ('19813', '东乡族自治县', '14513.7', 'area', '14514', '2');
INSERT INTO `sh_cascadedata` VALUES ('19812', '和政县', '14513.6', 'area', '14514', '2');
INSERT INTO `sh_cascadedata` VALUES ('19811', '广河县', '14513.5', 'area', '14514', '2');
INSERT INTO `sh_cascadedata` VALUES ('19810', '永靖县', '14513.4', 'area', '14513', '2');
INSERT INTO `sh_cascadedata` VALUES ('19809', '康乐县', '14513.3', 'area', '14513', '2');
INSERT INTO `sh_cascadedata` VALUES ('19808', '临夏县', '14513.2', 'area', '14513', '2');
INSERT INTO `sh_cascadedata` VALUES ('19807', '临夏市', '14513.1', 'area', '14513', '2');
INSERT INTO `sh_cascadedata` VALUES ('19806', '临夏回族自治州', '14513', 'area', '14513', '1');
INSERT INTO `sh_cascadedata` VALUES ('19805', '两当县', '14512.9', 'area', '14513', '2');
INSERT INTO `sh_cascadedata` VALUES ('19804', '徽　县', '14512.8', 'area', '14513', '2');
INSERT INTO `sh_cascadedata` VALUES ('19803', '礼　县', '14512.7', 'area', '14513', '2');
INSERT INTO `sh_cascadedata` VALUES ('19802', '西和县', '14512.6', 'area', '14513', '2');
INSERT INTO `sh_cascadedata` VALUES ('19801', '康　县', '14512.5', 'area', '14513', '2');
INSERT INTO `sh_cascadedata` VALUES ('19800', '宕昌县', '14512.4', 'area', '14512', '2');
INSERT INTO `sh_cascadedata` VALUES ('19799', '文　县', '14512.3', 'area', '14512', '2');
INSERT INTO `sh_cascadedata` VALUES ('19798', '成　县', '14512.2', 'area', '14512', '2');
INSERT INTO `sh_cascadedata` VALUES ('19797', '武都区', '14512.1', 'area', '14512', '2');
INSERT INTO `sh_cascadedata` VALUES ('19796', '陇南市', '14512', 'area', '14512', '1');
INSERT INTO `sh_cascadedata` VALUES ('19795', '岷　县', '14511.7', 'area', '14512', '2');
INSERT INTO `sh_cascadedata` VALUES ('19794', '漳　县', '14511.6', 'area', '14512', '2');
INSERT INTO `sh_cascadedata` VALUES ('19793', '临洮县', '14511.5', 'area', '14512', '2');
INSERT INTO `sh_cascadedata` VALUES ('19792', '渭源县', '14511.4', 'area', '14511', '2');
INSERT INTO `sh_cascadedata` VALUES ('19791', '陇西县', '14511.3', 'area', '14511', '2');
INSERT INTO `sh_cascadedata` VALUES ('19790', '通渭县', '14511.2', 'area', '14511', '2');
INSERT INTO `sh_cascadedata` VALUES ('19789', '安定区', '14511.1', 'area', '14511', '2');
INSERT INTO `sh_cascadedata` VALUES ('19788', '定西市', '14511', 'area', '14511', '1');
INSERT INTO `sh_cascadedata` VALUES ('19787', '镇原县', '14510.8', 'area', '14511', '2');
INSERT INTO `sh_cascadedata` VALUES ('19786', '宁　县', '14510.7', 'area', '14511', '2');
INSERT INTO `sh_cascadedata` VALUES ('19785', '正宁县', '14510.6', 'area', '14511', '2');
INSERT INTO `sh_cascadedata` VALUES ('19784', '合水县', '14510.5', 'area', '14511', '2');
INSERT INTO `sh_cascadedata` VALUES ('19783', '华池县', '14510.4', 'area', '14510', '2');
INSERT INTO `sh_cascadedata` VALUES ('19782', '环　县', '14510.3', 'area', '14510', '2');
INSERT INTO `sh_cascadedata` VALUES ('19781', '庆城县', '14510.2', 'area', '14510', '2');
INSERT INTO `sh_cascadedata` VALUES ('19780', '西峰区', '14510.1', 'area', '14510', '2');
INSERT INTO `sh_cascadedata` VALUES ('19779', '庆阳市', '14510', 'area', '14510', '1');
INSERT INTO `sh_cascadedata` VALUES ('19778', '敦煌市', '14509.7', 'area', '14510', '2');
INSERT INTO `sh_cascadedata` VALUES ('19777', '玉门市', '14509.6', 'area', '14510', '2');
INSERT INTO `sh_cascadedata` VALUES ('19776', '阿克塞哈萨克族自治县', '14509.5', 'area', '14510', '2');
INSERT INTO `sh_cascadedata` VALUES ('19775', '肃北蒙古族自治县', '14509.4', 'area', '14509', '2');
INSERT INTO `sh_cascadedata` VALUES ('19774', '安西县', '14509.3', 'area', '14509', '2');
INSERT INTO `sh_cascadedata` VALUES ('19773', '金塔县', '14509.2', 'area', '14509', '2');
INSERT INTO `sh_cascadedata` VALUES ('19772', '肃州区', '14509.1', 'area', '14509', '2');
INSERT INTO `sh_cascadedata` VALUES ('19771', '酒泉市', '14509', 'area', '14509', '1');
INSERT INTO `sh_cascadedata` VALUES ('19770', '静宁县', '14508.7', 'area', '14509', '2');
INSERT INTO `sh_cascadedata` VALUES ('19769', '庄浪县', '14508.6', 'area', '14509', '2');
INSERT INTO `sh_cascadedata` VALUES ('19768', '华亭县', '14508.5', 'area', '14509', '2');
INSERT INTO `sh_cascadedata` VALUES ('19767', '崇信县', '14508.4', 'area', '14508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19766', '灵台县', '14508.3', 'area', '14508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19765', '泾川县', '14508.2', 'area', '14508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19764', '崆峒区', '14508.1', 'area', '14508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19763', '平凉市', '14508', 'area', '14508', '1');
INSERT INTO `sh_cascadedata` VALUES ('19762', '山丹县', '14507.6', 'area', '14508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19761', '高台县', '14507.5', 'area', '14508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19760', '临泽县', '14507.4', 'area', '14507', '2');
INSERT INTO `sh_cascadedata` VALUES ('19759', '民乐县', '14507.3', 'area', '14507', '2');
INSERT INTO `sh_cascadedata` VALUES ('19758', '肃南裕固族自治县', '14507.2', 'area', '14507', '2');
INSERT INTO `sh_cascadedata` VALUES ('19757', '甘州区', '14507.1', 'area', '14507', '2');
INSERT INTO `sh_cascadedata` VALUES ('19756', '张掖市', '14507', 'area', '14507', '1');
INSERT INTO `sh_cascadedata` VALUES ('19755', '天祝藏族自治县', '14506.4', 'area', '14506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19754', '古浪县', '14506.3', 'area', '14506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19753', '民勤县', '14506.2', 'area', '14506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19752', '凉州区', '14506.1', 'area', '14506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19751', '武威市', '14506', 'area', '14506', '1');
INSERT INTO `sh_cascadedata` VALUES ('19750', '张家川回族自治县', '14505.7', 'area', '14506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19749', '武山县', '14505.6', 'area', '14506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19748', '甘谷县', '14505.5', 'area', '14506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19747', '秦安县', '14505.4', 'area', '14505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19746', '清水县', '14505.3', 'area', '14505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19745', '北道区', '14505.2', 'area', '14505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19744', '秦城区', '14505.1', 'area', '14505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19743', '天水市', '14505', 'area', '14505', '1');
INSERT INTO `sh_cascadedata` VALUES ('19742', '景泰县', '14504.5', 'area', '14505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19741', '会宁县', '14504.4', 'area', '14504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19740', '靖远县', '14504.3', 'area', '14504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19739', '平川区', '14504.2', 'area', '14504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19738', '白银区', '14504.1', 'area', '14504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19737', '白银市', '14504', 'area', '14504', '1');
INSERT INTO `sh_cascadedata` VALUES ('19736', '永昌县', '14503.2', 'area', '14503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19735', '金川区', '14503.1', 'area', '14503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19734', '金昌市', '14503', 'area', '14503', '1');
INSERT INTO `sh_cascadedata` VALUES ('19733', '嘉峪关市', '14502', 'area', '14502', '1');
INSERT INTO `sh_cascadedata` VALUES ('19732', '榆中县', '14501.8', 'area', '14502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19731', '皋兰县', '14501.7', 'area', '14502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19730', '永登县', '14501.6', 'area', '14502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19729', '红古区', '14501.5', 'area', '14502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19728', '安宁区', '14501.4', 'area', '14501', '2');
INSERT INTO `sh_cascadedata` VALUES ('19727', '西固区', '14501.3', 'area', '14501', '2');
INSERT INTO `sh_cascadedata` VALUES ('19726', '七里河区', '14501.2', 'area', '14501', '2');
INSERT INTO `sh_cascadedata` VALUES ('19725', '城关区', '14501.1', 'area', '14501', '2');
INSERT INTO `sh_cascadedata` VALUES ('19724', '兰州市', '14501', 'area', '14501', '1');
INSERT INTO `sh_cascadedata` VALUES ('19723', '甘肃省', '14500', 'area', '14500', '0');
INSERT INTO `sh_cascadedata` VALUES ('19722', '柞水县', '14010.7', 'area', '14011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19721', '镇安县', '14010.6', 'area', '14011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19720', '山阳县', '14010.5', 'area', '14011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19719', '商南县', '14010.4', 'area', '14010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19718', '丹凤县', '14010.3', 'area', '14010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19717', '洛南县', '14010.2', 'area', '14010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19716', '商州区', '14010.1', 'area', '14010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19715', '商洛市', '14010', 'area', '14010', '1');
INSERT INTO `sh_cascadedata` VALUES ('19714', '白河县', '14009.10', 'area', '14009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19713', '旬阳县', '14009.9', 'area', '14010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19712', '镇坪县', '14009.8', 'area', '14010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19711', '平利县', '14009.7', 'area', '14010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19710', '岚皋县', '14009.6', 'area', '14010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19709', '紫阳县', '14009.5', 'area', '14010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19708', '宁陕县', '14009.4', 'area', '14009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19707', '石泉县', '14009.3', 'area', '14009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19706', '汉阴县', '14009.2', 'area', '14009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19705', '汉滨区', '14009.1', 'area', '14009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19704', '安康市', '14009', 'area', '14009', '1');
INSERT INTO `sh_cascadedata` VALUES ('19703', '子洲县', '14008.12', 'area', '14008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19702', '清涧县', '14008.11', 'area', '14008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19701', '吴堡县', '14008.10', 'area', '14008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19700', '佳　县', '14008.9', 'area', '14009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19699', '米脂县', '14008.8', 'area', '14009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19698', '绥德县', '14008.7', 'area', '14009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19697', '定边县', '14008.6', 'area', '14009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19696', '靖边县', '14008.5', 'area', '14009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19695', '横山县', '14008.4', 'area', '14008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19694', '府谷县', '14008.3', 'area', '14008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19693', '神木县', '14008.2', 'area', '14008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19692', '榆阳区', '14008.1', 'area', '14008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19691', '榆林市', '14008', 'area', '14008', '1');
INSERT INTO `sh_cascadedata` VALUES ('19690', '佛坪县', '14007.11', 'area', '14007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19689', '留坝县', '14007.10', 'area', '14007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19688', '镇巴县', '14007.9', 'area', '14008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19687', '略阳县', '14007.8', 'area', '14008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19686', '宁强县', '14007.7', 'area', '14008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19685', '勉　县', '14007.6', 'area', '14008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19684', '西乡县', '14007.5', 'area', '14008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19683', '洋　县', '14007.4', 'area', '14007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19682', '城固县', '14007.3', 'area', '14007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19681', '南郑县', '14007.2', 'area', '14007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19680', '汉台区', '14007.1', 'area', '14007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19679', '汉中市', '14007', 'area', '14007', '1');
INSERT INTO `sh_cascadedata` VALUES ('19678', '黄陵县', '14006.13', 'area', '14006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19677', '黄龙县', '14006.12', 'area', '14006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19676', '宜川县', '14006.11', 'area', '14006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19675', '洛川县', '14006.10', 'area', '14006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19674', '富　县', '14006.9', 'area', '14007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19673', '甘泉县', '14006.8', 'area', '14007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19672', '吴旗县', '14006.7', 'area', '14007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19671', '志丹县', '14006.6', 'area', '14007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19670', '安塞县', '14006.5', 'area', '14007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19669', '子长县', '14006.4', 'area', '14006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19668', '延川县', '14006.3', 'area', '14006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19667', '延长县', '14006.2', 'area', '14006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19666', '宝塔区', '14006.1', 'area', '14006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19665', '延安市', '14006', 'area', '14006', '1');
INSERT INTO `sh_cascadedata` VALUES ('19664', '华阴市', '14005.11', 'area', '14005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19663', '韩城市', '14005.10', 'area', '14005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19662', '富平县', '14005.9', 'area', '14006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19661', '白水县', '14005.8', 'area', '14006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19660', '蒲城县', '14005.7', 'area', '14006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19659', '澄城县', '14005.6', 'area', '14006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19658', '合阳县', '14005.5', 'area', '14006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19657', '大荔县', '14005.4', 'area', '14005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19656', '潼关县', '14005.3', 'area', '14005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19655', '华　县', '14005.2', 'area', '14005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19654', '临渭区', '14005.1', 'area', '14005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19653', '渭南市', '14005', 'area', '14005', '1');
INSERT INTO `sh_cascadedata` VALUES ('19652', '兴平市', '14004.14', 'area', '14004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19651', '武功县', '14004.13', 'area', '14004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19650', '淳化县', '14004.12', 'area', '14004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19649', '旬邑县', '14004.11', 'area', '14004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19648', '长武县', '14004.10', 'area', '14004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19647', '彬　县', '14004.9', 'area', '14005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19646', '永寿县', '14004.8', 'area', '14005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19645', '礼泉县', '14004.7', 'area', '14005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19644', '乾　县', '14004.6', 'area', '14005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19643', '泾阳县', '14004.5', 'area', '14005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19642', '三原县', '14004.4', 'area', '14004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19641', '渭城区', '14004.3', 'area', '14004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19640', '杨凌区', '14004.2', 'area', '14004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19639', '秦都区', '14004.1', 'area', '14004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19638', '咸阳市', '14004', 'area', '14004', '1');
INSERT INTO `sh_cascadedata` VALUES ('19637', '太白县', '14003.12', 'area', '14003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19636', '凤　县', '14003.11', 'area', '14003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19635', '麟游县', '14003.10', 'area', '14003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19634', '千阳县', '14003.9', 'area', '14004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19633', '陇　县', '14003.8', 'area', '14004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19632', '眉　县', '14003.7', 'area', '14004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19631', '扶风县', '14003.6', 'area', '14004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19630', '岐山县', '14003.5', 'area', '14004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19629', '凤翔县', '14003.4', 'area', '14003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19628', '陈仓区', '14003.3', 'area', '14003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19627', '金台区', '14003.2', 'area', '14003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19626', '滨区', '14003.1', 'area', '14003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19625', '宝鸡市', '14003', 'area', '14003', '1');
INSERT INTO `sh_cascadedata` VALUES ('19624', '宜君县', '14002.4', 'area', '14002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19623', '耀州区', '14002.3', 'area', '14002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19622', '印台区', '14002.2', 'area', '14002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19621', '王益区', '14002.1', 'area', '14002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19620', '铜川市', '14002', 'area', '14002', '1');
INSERT INTO `sh_cascadedata` VALUES ('19619', '高陵县', '14001.13', 'area', '14001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19618', '户　县', '14001.12', 'area', '14001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19617', '周至县', '14001.11', 'area', '14001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19616', '蓝田县', '14001.10', 'area', '14001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19615', '长安区', '14001.9', 'area', '14002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19614', '临潼区', '14001.8', 'area', '14002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19613', '阎良区', '14001.7', 'area', '14002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19612', '雁塔区', '14001.6', 'area', '14002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19611', '未央区', '14001.5', 'area', '14002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19610', '灞桥区', '14001.4', 'area', '14001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19609', '莲湖区', '14001.3', 'area', '14001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19608', '碑林区', '14001.2', 'area', '14001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19607', '新城区', '14001.1', 'area', '14001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19606', '西安市', '14001', 'area', '14001', '1');
INSERT INTO `sh_cascadedata` VALUES ('19605', '陕西省', '14000', 'area', '14000', '0');
INSERT INTO `sh_cascadedata` VALUES ('19604', '朗　县', '13507.7', 'area', '13508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19603', '察隅县', '13507.6', 'area', '13508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19602', '波密县', '13507.5', 'area', '13508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19601', '墨脱县', '13507.4', 'area', '13507', '2');
INSERT INTO `sh_cascadedata` VALUES ('19600', '米林县', '13507.3', 'area', '13507', '2');
INSERT INTO `sh_cascadedata` VALUES ('19599', '工布江达县', '13507.2', 'area', '13507', '2');
INSERT INTO `sh_cascadedata` VALUES ('19598', '林芝县', '13507.1', 'area', '13507', '2');
INSERT INTO `sh_cascadedata` VALUES ('19597', '林芝地区', '13507', 'area', '13507', '1');
INSERT INTO `sh_cascadedata` VALUES ('19596', '措勤县', '13506.7', 'area', '13507', '2');
INSERT INTO `sh_cascadedata` VALUES ('19595', '改则县', '13506.6', 'area', '13507', '2');
INSERT INTO `sh_cascadedata` VALUES ('19594', '革吉县', '13506.5', 'area', '13507', '2');
INSERT INTO `sh_cascadedata` VALUES ('19593', '日土县', '13506.4', 'area', '13506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19592', '噶尔县', '13506.3', 'area', '13506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19591', '札达县', '13506.2', 'area', '13506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19590', '普兰县', '13506.1', 'area', '13506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19589', '阿里地区', '13506', 'area', '13506', '1');
INSERT INTO `sh_cascadedata` VALUES ('19588', '尼玛县', '13505.10', 'area', '13505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19587', '巴青县', '13505.9', 'area', '13506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19586', '班戈县', '13505.8', 'area', '13506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19585', '索　县', '13505.7', 'area', '13506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19584', '申扎县', '13505.6', 'area', '13506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19583', '安多县', '13505.5', 'area', '13506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19582', '聂荣县', '13505.4', 'area', '13505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19581', '比如县', '13505.3', 'area', '13505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19580', '嘉黎县', '13505.2', 'area', '13505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19579', '那曲县', '13505.1', 'area', '13505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19578', '那曲地区', '13505', 'area', '13505', '1');
INSERT INTO `sh_cascadedata` VALUES ('19577', '岗巴县', '13504.18', 'area', '13504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19576', '萨嘎县', '13504.17', 'area', '13504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19575', '聂拉木县', '13504.16', 'area', '13504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19574', '吉隆县', '13504.15', 'area', '13504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19573', '亚东县', '13504.14', 'area', '13504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19572', '仲巴县', '13504.13', 'area', '13504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19571', '定结县', '13504.12', 'area', '13504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19570', '康马县', '13504.11', 'area', '13504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19569', '仁布县', '13504.10', 'area', '13504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19568', '白朗县', '13504.9', 'area', '13505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19567', '谢通门县', '13504.8', 'area', '13505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19566', '昂仁县', '13504.7', 'area', '13505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19565', '拉孜县', '13504.6', 'area', '13505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19564', '萨迦县', '13504.5', 'area', '13505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19563', '定日县', '13504.4', 'area', '13504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19562', '江孜县', '13504.3', 'area', '13504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19561', '南木林县', '13504.2', 'area', '13504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19560', '日喀则市', '13504.1', 'area', '13504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19559', '日喀则地区', '13504', 'area', '13504', '1');
INSERT INTO `sh_cascadedata` VALUES ('19558', '浪卡子县', '13503.12', 'area', '13503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19557', '错那县', '13503.11', 'area', '13503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19556', '隆子县', '13503.10', 'area', '13503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19555', '加查县', '13503.9', 'area', '13504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19554', '洛扎县', '13503.8', 'area', '13504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19553', '措美县', '13503.7', 'area', '13504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19552', '曲松县', '13503.6', 'area', '13504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19551', '琼结县', '13503.5', 'area', '13504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19550', '桑日县', '13503.4', 'area', '13503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19549', '贡嘎县', '13503.3', 'area', '13503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19548', '扎囊县', '13503.2', 'area', '13503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19547', '乃东县', '13503.1', 'area', '13503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19546', '山南地区', '13503', 'area', '13503', '1');
INSERT INTO `sh_cascadedata` VALUES ('19545', '边坝县', '13502.11', 'area', '13502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19544', '洛隆县', '13502.10', 'area', '13502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19543', '芒康县', '13502.9', 'area', '13503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19542', '左贡县', '13502.8', 'area', '13503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19541', '八宿县', '13502.7', 'area', '13503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19540', '察雅县', '13502.6', 'area', '13503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19539', '丁青县', '13502.5', 'area', '13503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19538', '类乌齐县', '13502.4', 'area', '13502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19537', '贡觉县', '13502.3', 'area', '13502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19536', '江达县', '13502.2', 'area', '13502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19535', '昌都县', '13502.1', 'area', '13502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19534', '昌都地区', '13502', 'area', '13502', '1');
INSERT INTO `sh_cascadedata` VALUES ('19533', '墨竹工卡县', '13501.8', 'area', '13502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19532', '达孜县', '13501.7', 'area', '13502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19531', '堆龙德庆县', '13501.6', 'area', '13502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19530', '曲水县', '13501.5', 'area', '13502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19529', '尼木县', '13501.4', 'area', '13501', '2');
INSERT INTO `sh_cascadedata` VALUES ('19528', '当雄县', '13501.3', 'area', '13501', '2');
INSERT INTO `sh_cascadedata` VALUES ('19527', '林周县', '13501.2', 'area', '13501', '2');
INSERT INTO `sh_cascadedata` VALUES ('19526', '城关区', '13501.1', 'area', '13501', '2');
INSERT INTO `sh_cascadedata` VALUES ('19525', '拉萨市', '13501', 'area', '13501', '1');
INSERT INTO `sh_cascadedata` VALUES ('19524', '西藏自治区', '13500', 'area', '13500', '0');
INSERT INTO `sh_cascadedata` VALUES ('19523', '维西傈僳族自治县', '13016.3', 'area', '13016', '2');
INSERT INTO `sh_cascadedata` VALUES ('19522', '德钦县', '13016.2', 'area', '13016', '2');
INSERT INTO `sh_cascadedata` VALUES ('19521', '香格里拉县', '13016.1', 'area', '13016', '2');
INSERT INTO `sh_cascadedata` VALUES ('19520', '迪庆藏族自治州', '13016', 'area', '13016', '1');
INSERT INTO `sh_cascadedata` VALUES ('19519', '兰坪白族普米族自治县', '13015.4', 'area', '13015', '2');
INSERT INTO `sh_cascadedata` VALUES ('19518', '贡山独龙族怒族自治县', '13015.3', 'area', '13015', '2');
INSERT INTO `sh_cascadedata` VALUES ('19517', '福贡县', '13015.2', 'area', '13015', '2');
INSERT INTO `sh_cascadedata` VALUES ('19516', '泸水县', '13015.1', 'area', '13015', '2');
INSERT INTO `sh_cascadedata` VALUES ('19515', '怒江傈僳族自治州', '13015', 'area', '13015', '1');
INSERT INTO `sh_cascadedata` VALUES ('19514', '陇川县', '13014.5', 'area', '13015', '2');
INSERT INTO `sh_cascadedata` VALUES ('19513', '盈江县', '13014.4', 'area', '13014', '2');
INSERT INTO `sh_cascadedata` VALUES ('19512', '梁河县', '13014.3', 'area', '13014', '2');
INSERT INTO `sh_cascadedata` VALUES ('19511', '潞西市', '13014.2', 'area', '13014', '2');
INSERT INTO `sh_cascadedata` VALUES ('19510', '瑞丽市', '13014.1', 'area', '13014', '2');
INSERT INTO `sh_cascadedata` VALUES ('19509', '德宏傣族景颇族自治州', '13014', 'area', '13014', '1');
INSERT INTO `sh_cascadedata` VALUES ('19508', '鹤庆县', '13013.12', 'area', '13013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19507', '剑川县', '13013.11', 'area', '13013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19506', '洱源县', '13013.10', 'area', '13013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19505', '云龙县', '13013.9', 'area', '13014', '2');
INSERT INTO `sh_cascadedata` VALUES ('19504', '永平县', '13013.8', 'area', '13014', '2');
INSERT INTO `sh_cascadedata` VALUES ('19503', '巍山彝族回族自治县', '13013.7', 'area', '13014', '2');
INSERT INTO `sh_cascadedata` VALUES ('19502', '南涧彝族自治县', '13013.6', 'area', '13014', '2');
INSERT INTO `sh_cascadedata` VALUES ('19501', '弥渡县', '13013.5', 'area', '13014', '2');
INSERT INTO `sh_cascadedata` VALUES ('19500', '宾川县', '13013.4', 'area', '13013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19499', '祥云县', '13013.3', 'area', '13013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19498', '漾濞彝族自治县', '13013.2', 'area', '13013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19497', '大理市', '13013.1', 'area', '13013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19496', '大理白族自治州', '13013', 'area', '13013', '1');
INSERT INTO `sh_cascadedata` VALUES ('19495', '勐腊县', '13012.3', 'area', '13012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19494', '勐海县', '13012.2', 'area', '13012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19493', '景洪市', '13012.1', 'area', '13012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19492', '西双版纳傣族自治州', '13012', 'area', '13012', '1');
INSERT INTO `sh_cascadedata` VALUES ('19491', '富宁县', '13011.8', 'area', '13012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19490', '广南县', '13011.7', 'area', '13012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19489', '丘北县', '13011.6', 'area', '13012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19488', '马关县', '13011.5', 'area', '13012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19487', '麻栗坡县', '13011.4', 'area', '13011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19486', '西畴县', '13011.3', 'area', '13011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19485', '砚山县', '13011.2', 'area', '13011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19484', '文山县', '13011.1', 'area', '13011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19483', '文山壮族苗族自治州', '13011', 'area', '13011', '1');
INSERT INTO `sh_cascadedata` VALUES ('19482', '河口瑶族自治县', '13010.12', 'area', '13010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19481', '绿春县', '13010.11', 'area', '13010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19480', '金平苗族瑶族傣族自治县', '13010.10', 'area', '13010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19479', '元阳县', '13010.9', 'area', '13011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19478', '泸西县', '13010.8', 'area', '13011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19477', '弥勒县', '13010.7', 'area', '13011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19476', '石屏县', '13010.6', 'area', '13011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19475', '建水县', '13010.5', 'area', '13011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19474', '屏边苗族自治县', '13010.4', 'area', '13010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19473', '蒙自县', '13010.3', 'area', '13010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19472', '开远市', '13010.2', 'area', '13010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19471', '个旧市', '13010.1', 'area', '13010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19470', '红河哈尼族彝族自治州', '13010', 'area', '13010', '1');
INSERT INTO `sh_cascadedata` VALUES ('19469', '禄丰县', '13009.10', 'area', '13009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19468', '武定县', '13009.9', 'area', '13010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19467', '元谋县', '13009.8', 'area', '13010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19466', '永仁县', '13009.7', 'area', '13010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19465', '大姚县', '13009.6', 'area', '13010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19464', '姚安县', '13009.5', 'area', '13010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19463', '南华县', '13009.4', 'area', '13009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19462', '牟定县', '13009.3', 'area', '13009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19461', '双柏县', '13009.2', 'area', '13009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19460', '楚雄市', '13009.1', 'area', '13009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19459', '楚雄彝族自治州', '13009', 'area', '13009', '1');
INSERT INTO `sh_cascadedata` VALUES ('19458', '沧源佤族自治县', '13008.8', 'area', '13009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19457', '耿马傣族佤族自治县', '13008.7', 'area', '13009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19456', '双江拉祜族佤族布朗族傣族自治县', '13008.6', 'area', '13009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19455', '镇康县', '13008.5', 'area', '13009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19454', '永德县', '13008.4', 'area', '13008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19453', '云　县', '13008.3', 'area', '13008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19452', '凤庆县', '13008.2', 'area', '13008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19451', '临翔区', '13008.1', 'area', '13008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19450', '临沧市', '13008', 'area', '13008', '1');
INSERT INTO `sh_cascadedata` VALUES ('19449', '西盟佤族自治县', '13007.10', 'area', '13007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19448', '澜沧拉祜族自治县', '13007.9', 'area', '13008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19447', '孟连傣族拉祜族佤族自治县', '13007.8', 'area', '13008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19446', '江城哈尼族彝族自治县', '13007.7', 'area', '13008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19445', '镇沅彝族哈尼族拉祜族自治县', '13007.6', 'area', '13008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19444', '景谷傣族彝族自治县', '13007.5', 'area', '13008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19443', '景东彝族自治县', '13007.4', 'area', '13007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19442', '墨江哈尼族自治县', '13007.3', 'area', '13007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19441', '普洱哈尼族彝族自治县', '13007.2', 'area', '13007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19440', '翠云区', '13007.1', 'area', '13007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19439', '思茅市', '13007', 'area', '13007', '1');
INSERT INTO `sh_cascadedata` VALUES ('19438', '宁蒗彝族自治县', '13006.5', 'area', '13007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19437', '华坪县', '13006.4', 'area', '13006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19436', '永胜县', '13006.3', 'area', '13006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19435', '玉龙纳西族自治县', '13006.2', 'area', '13006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19434', '古城区', '13006.1', 'area', '13006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19433', '丽江市', '13006', 'area', '13006', '1');
INSERT INTO `sh_cascadedata` VALUES ('19432', '水富县', '13005.11', 'area', '13005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19431', '威信县', '13005.10', 'area', '13005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19430', '彝良县', '13005.9', 'area', '13006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19429', '镇雄县', '13005.8', 'area', '13006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19428', '绥江县', '13005.7', 'area', '13006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19427', '永善县', '13005.6', 'area', '13006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19426', '大关县', '13005.5', 'area', '13006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19425', '盐津县', '13005.4', 'area', '13005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19424', '巧家县', '13005.3', 'area', '13005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19423', '鲁甸县', '13005.2', 'area', '13005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19422', '昭阳区', '13005.1', 'area', '13005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19421', '昭通市', '13005', 'area', '13005', '1');
INSERT INTO `sh_cascadedata` VALUES ('19420', '昌宁县', '13004.5', 'area', '13005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19419', '龙陵县', '13004.4', 'area', '13004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19418', '腾冲县', '13004.3', 'area', '13004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19417', '施甸县', '13004.2', 'area', '13004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19416', '隆阳区', '13004.1', 'area', '13004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19415', '保山市', '13004', 'area', '13004', '1');
INSERT INTO `sh_cascadedata` VALUES ('19414', '元江哈尼族彝族傣族自治县', '13003.9', 'area', '13004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19413', '新平彝族傣族自治县', '13003.8', 'area', '13004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19412', '峨山彝族自治县', '13003.7', 'area', '13004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19411', '易门县', '13003.6', 'area', '13004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19410', '华宁县', '13003.5', 'area', '13004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19409', '通海县', '13003.4', 'area', '13003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19408', '澄江县', '13003.3', 'area', '13003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19407', '江川县', '13003.2', 'area', '13003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19406', '红塔区', '13003.1', 'area', '13003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19405', '玉溪市', '13003', 'area', '13003', '1');
INSERT INTO `sh_cascadedata` VALUES ('19404', '宣威市', '13002.9', 'area', '13003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19403', '沾益县', '13002.8', 'area', '13003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19402', '会泽县', '13002.7', 'area', '13003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19401', '富源县', '13002.6', 'area', '13003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19400', '罗平县', '13002.5', 'area', '13003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19399', '师宗县', '13002.4', 'area', '13002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19398', '陆良县', '13002.3', 'area', '13002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19397', '马龙县', '13002.2', 'area', '13002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19396', '麒麟区', '13002.1', 'area', '13002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19395', '曲靖市', '13002', 'area', '13002', '1');
INSERT INTO `sh_cascadedata` VALUES ('19394', '安宁市', '13001.14', 'area', '13001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19393', '寻甸回族彝族自治县', '13001.13', 'area', '13001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19392', '禄劝彝族苗族自治县', '13001.12', 'area', '13001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19391', '嵩明县', '13001.11', 'area', '13001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19390', '石林彝族自治县', '13001.10', 'area', '13001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19389', '宜良县', '13001.9', 'area', '13002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19388', '富民县', '13001.8', 'area', '13002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19387', '晋宁县', '13001.7', 'area', '13002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19386', '呈贡县', '13001.6', 'area', '13002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19385', '东川区', '13001.5', 'area', '13002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19384', '西山区', '13001.4', 'area', '13001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19383', '官渡区', '13001.3', 'area', '13001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19382', '盘龙区', '13001.2', 'area', '13001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19381', '五华区', '13001.1', 'area', '13001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19380', '昆明市', '13001', 'area', '13001', '1');
INSERT INTO `sh_cascadedata` VALUES ('19379', '云南省', '13000', 'area', '13000', '0');
INSERT INTO `sh_cascadedata` VALUES ('19378', '三都水族自治县', '12509.12', 'area', '12509', '2');
INSERT INTO `sh_cascadedata` VALUES ('19377', '惠水县', '12509.11', 'area', '12509', '2');
INSERT INTO `sh_cascadedata` VALUES ('19376', '龙里县', '12509.10', 'area', '12509', '2');
INSERT INTO `sh_cascadedata` VALUES ('19375', '长顺县', '12509.9', 'area', '12510', '2');
INSERT INTO `sh_cascadedata` VALUES ('19374', '罗甸县', '12509.8', 'area', '12510', '2');
INSERT INTO `sh_cascadedata` VALUES ('19373', '平塘县', '12509.7', 'area', '12510', '2');
INSERT INTO `sh_cascadedata` VALUES ('19372', '独山县', '12509.6', 'area', '12510', '2');
INSERT INTO `sh_cascadedata` VALUES ('19371', '瓮安县', '12509.5', 'area', '12510', '2');
INSERT INTO `sh_cascadedata` VALUES ('19370', '贵定县', '12509.4', 'area', '12509', '2');
INSERT INTO `sh_cascadedata` VALUES ('19369', '荔波县', '12509.3', 'area', '12509', '2');
INSERT INTO `sh_cascadedata` VALUES ('19368', '福泉市', '12509.2', 'area', '12509', '2');
INSERT INTO `sh_cascadedata` VALUES ('19367', '都匀市', '12509.1', 'area', '12509', '2');
INSERT INTO `sh_cascadedata` VALUES ('19366', '黔南布依族苗族自治州', '12509', 'area', '12509', '1');
INSERT INTO `sh_cascadedata` VALUES ('19365', '麻江县', '12508.15', 'area', '12508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19364', '雷山县', '12508.14', 'area', '12508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19363', '从江县', '12508.13', 'area', '12508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19362', '榕江县', '12508.12', 'area', '12508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19361', '黎平县', '12508.11', 'area', '12508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19360', '台江县', '12508.10', 'area', '12508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19359', '剑河县', '12508.9', 'area', '12509', '2');
INSERT INTO `sh_cascadedata` VALUES ('19358', '锦屏县', '12508.8', 'area', '12509', '2');
INSERT INTO `sh_cascadedata` VALUES ('19357', '天柱县', '12508.7', 'area', '12509', '2');
INSERT INTO `sh_cascadedata` VALUES ('19356', '岑巩县', '12508.6', 'area', '12509', '2');
INSERT INTO `sh_cascadedata` VALUES ('19355', '镇远县', '12508.5', 'area', '12509', '2');
INSERT INTO `sh_cascadedata` VALUES ('19354', '三穗县', '12508.4', 'area', '12508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19353', '施秉县', '12508.3', 'area', '12508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19352', '黄平县', '12508.2', 'area', '12508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19351', '凯里市', '12508.1', 'area', '12508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19350', '黔东南苗族侗族自治州', '12508', 'area', '12508', '1');
INSERT INTO `sh_cascadedata` VALUES ('19349', '赫章县', '12507.8', 'area', '12508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19348', '威宁彝族回族苗族自治县', '12507.7', 'area', '12508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19347', '纳雍县', '12507.6', 'area', '12508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19346', '织金县', '12507.5', 'area', '12508', '2');
INSERT INTO `sh_cascadedata` VALUES ('19345', '金沙县', '12507.4', 'area', '12507', '2');
INSERT INTO `sh_cascadedata` VALUES ('19344', '黔西县', '12507.3', 'area', '12507', '2');
INSERT INTO `sh_cascadedata` VALUES ('19343', '大方县', '12507.2', 'area', '12507', '2');
INSERT INTO `sh_cascadedata` VALUES ('19342', '毕节市', '12507.1', 'area', '12507', '2');
INSERT INTO `sh_cascadedata` VALUES ('19341', '毕节地区', '12507', 'area', '12507', '1');
INSERT INTO `sh_cascadedata` VALUES ('19340', '安龙县', '12506.8', 'area', '12507', '2');
INSERT INTO `sh_cascadedata` VALUES ('19339', '册亨县', '12506.7', 'area', '12507', '2');
INSERT INTO `sh_cascadedata` VALUES ('19338', '望谟县', '12506.6', 'area', '12507', '2');
INSERT INTO `sh_cascadedata` VALUES ('19337', '贞丰县', '12506.5', 'area', '12507', '2');
INSERT INTO `sh_cascadedata` VALUES ('19336', '晴隆县', '12506.4', 'area', '12506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19335', '普安县', '12506.3', 'area', '12506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19334', '兴仁县', '12506.2', 'area', '12506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19333', '兴义市', '12506.1', 'area', '12506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19332', '黔西南布依族苗族自治州', '12506', 'area', '12506', '1');
INSERT INTO `sh_cascadedata` VALUES ('19331', '万山特区', '12505.10', 'area', '12505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19330', '松桃苗族自治县', '12505.9', 'area', '12506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19329', '沿河土家族自治县', '12505.8', 'area', '12506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19328', '德江县', '12505.7', 'area', '12506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19327', '印江土家族苗族自治县', '12505.6', 'area', '12506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19326', '思南县', '12505.5', 'area', '12506', '2');
INSERT INTO `sh_cascadedata` VALUES ('19325', '石阡县', '12505.4', 'area', '12505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19324', '玉屏侗族自治县', '12505.3', 'area', '12505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19323', '江口县', '12505.2', 'area', '12505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19322', '铜仁市', '12505.1', 'area', '12505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19321', '铜仁地区', '12505', 'area', '12505', '1');
INSERT INTO `sh_cascadedata` VALUES ('19320', '紫云苗族布依族自治县', '12504.6', 'area', '12505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19319', '关岭布依族苗族自治县', '12504.5', 'area', '12505', '2');
INSERT INTO `sh_cascadedata` VALUES ('19318', '镇宁布依族苗族自治县', '12504.4', 'area', '12504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19317', '普定县', '12504.3', 'area', '12504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19316', '平坝县', '12504.2', 'area', '12504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19315', '西秀区', '12504.1', 'area', '12504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19314', '安顺市', '12504', 'area', '12504', '1');
INSERT INTO `sh_cascadedata` VALUES ('19313', '仁怀市', '12503.14', 'area', '12503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19312', '赤水市', '12503.13', 'area', '12503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19311', '习水县', '12503.12', 'area', '12503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19310', '余庆县', '12503.11', 'area', '12503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19309', '湄潭县', '12503.10', 'area', '12503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19308', '凤冈县', '12503.9', 'area', '12504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19307', '务川仡佬族苗族自治县', '12503.8', 'area', '12504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19306', '道真仡佬族苗族自治县', '12503.7', 'area', '12504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19305', '正安县', '12503.6', 'area', '12504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19304', '绥阳县', '12503.5', 'area', '12504', '2');
INSERT INTO `sh_cascadedata` VALUES ('19303', '桐梓县', '12503.4', 'area', '12503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19302', '遵义县', '12503.3', 'area', '12503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19301', '汇川区', '12503.2', 'area', '12503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19300', '红花岗区', '12503.1', 'area', '12503', '2');
INSERT INTO `sh_cascadedata` VALUES ('19299', '遵义市', '12503', 'area', '12503', '1');
INSERT INTO `sh_cascadedata` VALUES ('19298', '盘　县', '12502.4', 'area', '12502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19297', '水城县', '12502.3', 'area', '12502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19296', '六枝特区', '12502.2', 'area', '12502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19295', '钟山区', '12502.1', 'area', '12502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19294', '六盘水市', '12502', 'area', '12502', '1');
INSERT INTO `sh_cascadedata` VALUES ('19293', '清镇市', '12501.10', 'area', '12501', '2');
INSERT INTO `sh_cascadedata` VALUES ('19292', '修文县', '12501.9', 'area', '12502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19291', '息烽县', '12501.8', 'area', '12502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19290', '开阳县', '12501.7', 'area', '12502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19289', '小河区', '12501.6', 'area', '12502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19288', '白云区', '12501.5', 'area', '12502', '2');
INSERT INTO `sh_cascadedata` VALUES ('19287', '乌当区', '12501.4', 'area', '12501', '2');
INSERT INTO `sh_cascadedata` VALUES ('19286', '花溪区', '12501.3', 'area', '12501', '2');
INSERT INTO `sh_cascadedata` VALUES ('19285', '云岩区', '12501.2', 'area', '12501', '2');
INSERT INTO `sh_cascadedata` VALUES ('19284', '南明区', '12501.1', 'area', '12501', '2');
INSERT INTO `sh_cascadedata` VALUES ('19283', '贵阳市', '12501', 'area', '12501', '1');
INSERT INTO `sh_cascadedata` VALUES ('19282', '贵州省', '12500', 'area', '12500', '0');
INSERT INTO `sh_cascadedata` VALUES ('19281', '雷波县', '12021.17', 'area', '12021', '2');
INSERT INTO `sh_cascadedata` VALUES ('19280', '美姑县', '12021.16', 'area', '12021', '2');
INSERT INTO `sh_cascadedata` VALUES ('19279', '甘洛县', '12021.15', 'area', '12021', '2');
INSERT INTO `sh_cascadedata` VALUES ('19278', '越西县', '12021.14', 'area', '12021', '2');
INSERT INTO `sh_cascadedata` VALUES ('19277', '冕宁县', '12021.13', 'area', '12021', '2');
INSERT INTO `sh_cascadedata` VALUES ('19276', '喜德县', '12021.12', 'area', '12021', '2');
INSERT INTO `sh_cascadedata` VALUES ('19275', '昭觉县', '12021.11', 'area', '12021', '2');
INSERT INTO `sh_cascadedata` VALUES ('19274', '金阳县', '12021.10', 'area', '12021', '2');
INSERT INTO `sh_cascadedata` VALUES ('19273', '布拖县', '12021.9', 'area', '12022', '2');
INSERT INTO `sh_cascadedata` VALUES ('19272', '普格县', '12021.8', 'area', '12022', '2');
INSERT INTO `sh_cascadedata` VALUES ('19271', '宁南县', '12021.7', 'area', '12022', '2');
INSERT INTO `sh_cascadedata` VALUES ('19270', '会东县', '12021.6', 'area', '12022', '2');
INSERT INTO `sh_cascadedata` VALUES ('19269', '会理县', '12021.5', 'area', '12022', '2');
INSERT INTO `sh_cascadedata` VALUES ('19268', '德昌县', '12021.4', 'area', '12021', '2');
INSERT INTO `sh_cascadedata` VALUES ('19267', '盐源县', '12021.3', 'area', '12021', '2');
INSERT INTO `sh_cascadedata` VALUES ('19266', '木里藏族自治县', '12021.2', 'area', '12021', '2');
INSERT INTO `sh_cascadedata` VALUES ('19265', '西昌市', '12021.1', 'area', '12021', '2');
INSERT INTO `sh_cascadedata` VALUES ('19264', '凉山彝族自治州', '12021', 'area', '12021', '1');
INSERT INTO `sh_cascadedata` VALUES ('19263', '得荣县', '12020.18', 'area', '12020', '2');
INSERT INTO `sh_cascadedata` VALUES ('19262', '稻城县', '12020.17', 'area', '12020', '2');
INSERT INTO `sh_cascadedata` VALUES ('19261', '乡城县', '12020.16', 'area', '12020', '2');
INSERT INTO `sh_cascadedata` VALUES ('19260', '巴塘县', '12020.15', 'area', '12020', '2');
INSERT INTO `sh_cascadedata` VALUES ('19259', '理塘县', '12020.14', 'area', '12020', '2');
INSERT INTO `sh_cascadedata` VALUES ('19258', '色达县', '12020.13', 'area', '12020', '2');
INSERT INTO `sh_cascadedata` VALUES ('19257', '石渠县', '12020.12', 'area', '12020', '2');
INSERT INTO `sh_cascadedata` VALUES ('19256', '白玉县', '12020.11', 'area', '12020', '2');
INSERT INTO `sh_cascadedata` VALUES ('19255', '德格县', '12020.10', 'area', '12020', '2');
INSERT INTO `sh_cascadedata` VALUES ('19254', '新龙县', '12020.9', 'area', '12021', '2');
INSERT INTO `sh_cascadedata` VALUES ('19253', '甘孜县', '12020.8', 'area', '12021', '2');
INSERT INTO `sh_cascadedata` VALUES ('19252', '炉霍县', '12020.7', 'area', '12021', '2');
INSERT INTO `sh_cascadedata` VALUES ('19251', '道孚县', '12020.6', 'area', '12021', '2');
INSERT INTO `sh_cascadedata` VALUES ('19250', '雅江县', '12020.5', 'area', '12021', '2');
INSERT INTO `sh_cascadedata` VALUES ('19249', '九龙县', '12020.4', 'area', '12020', '2');
INSERT INTO `sh_cascadedata` VALUES ('19248', '丹巴县', '12020.3', 'area', '12020', '2');
INSERT INTO `sh_cascadedata` VALUES ('19247', '泸定县', '12020.2', 'area', '12020', '2');
INSERT INTO `sh_cascadedata` VALUES ('19246', '康定县', '12020.1', 'area', '12020', '2');
INSERT INTO `sh_cascadedata` VALUES ('19245', '甘孜藏族自治州', '12020', 'area', '12020', '1');
INSERT INTO `sh_cascadedata` VALUES ('19244', '红原县', '12019.13', 'area', '12019', '2');
INSERT INTO `sh_cascadedata` VALUES ('19243', '若尔盖县', '12019.12', 'area', '12019', '2');
INSERT INTO `sh_cascadedata` VALUES ('19242', '阿坝县', '12019.11', 'area', '12019', '2');
INSERT INTO `sh_cascadedata` VALUES ('19241', '壤塘县', '12019.10', 'area', '12019', '2');
INSERT INTO `sh_cascadedata` VALUES ('19240', '马尔康县', '12019.9', 'area', '12020', '2');
INSERT INTO `sh_cascadedata` VALUES ('19239', '黑水县', '12019.8', 'area', '12020', '2');
INSERT INTO `sh_cascadedata` VALUES ('19238', '小金县', '12019.7', 'area', '12020', '2');
INSERT INTO `sh_cascadedata` VALUES ('19237', '金川县', '12019.6', 'area', '12020', '2');
INSERT INTO `sh_cascadedata` VALUES ('19236', '九寨沟县', '12019.5', 'area', '12020', '2');
INSERT INTO `sh_cascadedata` VALUES ('19235', '松潘县', '12019.4', 'area', '12019', '2');
INSERT INTO `sh_cascadedata` VALUES ('19234', '茂　县', '12019.3', 'area', '12019', '2');
INSERT INTO `sh_cascadedata` VALUES ('19233', '理　县', '12019.2', 'area', '12019', '2');
INSERT INTO `sh_cascadedata` VALUES ('19232', '汶川县', '12019.1', 'area', '12019', '2');
INSERT INTO `sh_cascadedata` VALUES ('19231', '阿坝藏族羌族自治州', '12019', 'area', '12019', '1');
INSERT INTO `sh_cascadedata` VALUES ('19230', '简阳市', '12018.4', 'area', '12018', '2');
INSERT INTO `sh_cascadedata` VALUES ('19229', '乐至县', '12018.3', 'area', '12018', '2');
INSERT INTO `sh_cascadedata` VALUES ('19228', '安岳县', '12018.2', 'area', '12018', '2');
INSERT INTO `sh_cascadedata` VALUES ('19227', '雁江区', '12018.1', 'area', '12018', '2');
INSERT INTO `sh_cascadedata` VALUES ('19226', '资阳市', '12018', 'area', '12018', '1');
INSERT INTO `sh_cascadedata` VALUES ('19225', '平昌县', '12017.4', 'area', '12017', '2');
INSERT INTO `sh_cascadedata` VALUES ('19224', '南江县', '12017.3', 'area', '12017', '2');
INSERT INTO `sh_cascadedata` VALUES ('19223', '通江县', '12017.2', 'area', '12017', '2');
INSERT INTO `sh_cascadedata` VALUES ('19222', '巴州区', '12017.1', 'area', '12017', '2');
INSERT INTO `sh_cascadedata` VALUES ('19221', '巴中市', '12017', 'area', '12017', '1');
INSERT INTO `sh_cascadedata` VALUES ('19220', '宝兴县', '12016.8', 'area', '12017', '2');
INSERT INTO `sh_cascadedata` VALUES ('19219', '芦山县', '12016.7', 'area', '12017', '2');
INSERT INTO `sh_cascadedata` VALUES ('19218', '天全县', '12016.6', 'area', '12017', '2');
INSERT INTO `sh_cascadedata` VALUES ('19217', '石棉县', '12016.5', 'area', '12017', '2');
INSERT INTO `sh_cascadedata` VALUES ('19216', '汉源县', '12016.4', 'area', '12016', '2');
INSERT INTO `sh_cascadedata` VALUES ('19215', '荥经县', '12016.3', 'area', '12016', '2');
INSERT INTO `sh_cascadedata` VALUES ('19214', '名山县', '12016.2', 'area', '12016', '2');
INSERT INTO `sh_cascadedata` VALUES ('19213', '雨城区', '12016.1', 'area', '12016', '2');
INSERT INTO `sh_cascadedata` VALUES ('19212', '雅安市', '12016', 'area', '12016', '1');
INSERT INTO `sh_cascadedata` VALUES ('19211', '万源市', '12015.7', 'area', '12016', '2');
INSERT INTO `sh_cascadedata` VALUES ('19210', '渠　县', '12015.6', 'area', '12016', '2');
INSERT INTO `sh_cascadedata` VALUES ('19209', '大竹县', '12015.5', 'area', '12016', '2');
INSERT INTO `sh_cascadedata` VALUES ('19208', '开江县', '12015.4', 'area', '12015', '2');
INSERT INTO `sh_cascadedata` VALUES ('19207', '宣汉县', '12015.3', 'area', '12015', '2');
INSERT INTO `sh_cascadedata` VALUES ('19206', '达　县', '12015.2', 'area', '12015', '2');
INSERT INTO `sh_cascadedata` VALUES ('19205', '通川区', '12015.1', 'area', '12015', '2');
INSERT INTO `sh_cascadedata` VALUES ('19204', '达州市', '12015', 'area', '12015', '1');
INSERT INTO `sh_cascadedata` VALUES ('19203', '华莹市', '12014.5', 'area', '12015', '2');
INSERT INTO `sh_cascadedata` VALUES ('19202', '邻水县', '12014.4', 'area', '12014', '2');
INSERT INTO `sh_cascadedata` VALUES ('19201', '武胜县', '12014.3', 'area', '12014', '2');
INSERT INTO `sh_cascadedata` VALUES ('19200', '岳池县', '12014.2', 'area', '12014', '2');
INSERT INTO `sh_cascadedata` VALUES ('19199', '广安区', '12014.1', 'area', '12014', '2');
INSERT INTO `sh_cascadedata` VALUES ('19198', '广安市', '12014', 'area', '12014', '1');
INSERT INTO `sh_cascadedata` VALUES ('19197', '屏山县', '12013.10', 'area', '12013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19196', '兴文县', '12013.9', 'area', '12014', '2');
INSERT INTO `sh_cascadedata` VALUES ('19195', '筠连县', '12013.8', 'area', '12014', '2');
INSERT INTO `sh_cascadedata` VALUES ('19194', '珙　县', '12013.7', 'area', '12014', '2');
INSERT INTO `sh_cascadedata` VALUES ('19193', '高　县', '12013.6', 'area', '12014', '2');
INSERT INTO `sh_cascadedata` VALUES ('19192', '长宁县', '12013.5', 'area', '12014', '2');
INSERT INTO `sh_cascadedata` VALUES ('19191', '江安县', '12013.4', 'area', '12013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19190', '南溪县', '12013.3', 'area', '12013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19189', '宜宾县', '12013.2', 'area', '12013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19188', '翠屏区', '12013.1', 'area', '12013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19187', '宜宾市', '12013', 'area', '12013', '1');
INSERT INTO `sh_cascadedata` VALUES ('19186', '青神县', '12012.6', 'area', '12013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19185', '丹棱县', '12012.5', 'area', '12013', '2');
INSERT INTO `sh_cascadedata` VALUES ('19184', '洪雅县', '12012.4', 'area', '12012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19183', '彭山县', '12012.3', 'area', '12012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19182', '仁寿县', '12012.2', 'area', '12012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19181', '东坡区', '12012.1', 'area', '12012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19180', '眉山市', '12012', 'area', '12012', '1');
INSERT INTO `sh_cascadedata` VALUES ('19179', '阆中市', '12011.9', 'area', '12012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19178', '西充县', '12011.8', 'area', '12012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19177', '仪陇县', '12011.7', 'area', '12012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19176', '蓬安县', '12011.6', 'area', '12012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19175', '营山县', '12011.5', 'area', '12012', '2');
INSERT INTO `sh_cascadedata` VALUES ('19174', '南部县', '12011.4', 'area', '12011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19173', '嘉陵区', '12011.3', 'area', '12011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19172', '高坪区', '12011.2', 'area', '12011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19171', '顺庆区', '12011.1', 'area', '12011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19170', '南充市', '12011', 'area', '12011', '1');
INSERT INTO `sh_cascadedata` VALUES ('19169', '峨眉山市', '12010.11', 'area', '12010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19168', '马边彝族自治县', '12010.10', 'area', '12010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19167', '峨边彝族自治县', '12010.9', 'area', '12011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19166', '沐川县', '12010.8', 'area', '12011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19165', '夹江县', '12010.7', 'area', '12011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19164', '井研县', '12010.6', 'area', '12011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19163', '犍为县', '12010.5', 'area', '12011', '2');
INSERT INTO `sh_cascadedata` VALUES ('19162', '金口河区', '12010.4', 'area', '12010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19161', '五通桥区', '12010.3', 'area', '12010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19160', '沙湾区', '12010.2', 'area', '12010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19159', '市中区', '12010.1', 'area', '12010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19158', '乐山市', '12010', 'area', '12010', '1');
INSERT INTO `sh_cascadedata` VALUES ('19157', '隆昌县', '12009.5', 'area', '12010', '2');
INSERT INTO `sh_cascadedata` VALUES ('19156', '资中县', '12009.4', 'area', '12009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19155', '威远县', '12009.3', 'area', '12009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19154', '东兴区', '12009.2', 'area', '12009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19153', '市中区', '12009.1', 'area', '12009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19152', '内江市', '12009', 'area', '12009', '1');
INSERT INTO `sh_cascadedata` VALUES ('19151', '大英县', '12008.5', 'area', '12009', '2');
INSERT INTO `sh_cascadedata` VALUES ('19150', '射洪县', '12008.4', 'area', '12008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19149', '蓬溪县', '12008.3', 'area', '12008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19148', '安居区', '12008.2', 'area', '12008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19147', '船山区', '12008.1', 'area', '12008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19146', '遂宁市', '12008', 'area', '12008', '1');
INSERT INTO `sh_cascadedata` VALUES ('19145', '苍溪县', '12007.7', 'area', '12008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19144', '剑阁县', '12007.6', 'area', '12008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19143', '青川县', '12007.5', 'area', '12008', '2');
INSERT INTO `sh_cascadedata` VALUES ('19142', '旺苍县', '12007.4', 'area', '12007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19141', '朝天区', '12007.3', 'area', '12007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19140', '元坝区', '12007.2', 'area', '12007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19139', '市中区', '12007.1', 'area', '12007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19138', '广元市', '12007', 'area', '12007', '1');
INSERT INTO `sh_cascadedata` VALUES ('19137', '江油市', '12006.9', 'area', '12007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19136', '平武县', '12006.8', 'area', '12007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19135', '北川羌族自治县', '12006.7', 'area', '12007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19134', '梓潼县', '12006.6', 'area', '12007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19133', '安　县', '12006.5', 'area', '12007', '2');
INSERT INTO `sh_cascadedata` VALUES ('19132', '盐亭县', '12006.4', 'area', '12006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19131', '三台县', '12006.3', 'area', '12006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19130', '游仙区', '12006.2', 'area', '12006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19129', '涪城区', '12006.1', 'area', '12006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19128', '绵阳市', '12006', 'area', '12006', '1');
INSERT INTO `sh_cascadedata` VALUES ('19127', '绵竹市', '12005.6', 'area', '12006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19126', '什邡市', '12005.5', 'area', '12006', '2');
INSERT INTO `sh_cascadedata` VALUES ('19125', '广汉市', '12005.4', 'area', '12005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19124', '罗江县', '12005.3', 'area', '12005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19123', '中江县', '12005.2', 'area', '12005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19122', '旌阳区', '12005.1', 'area', '12005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19121', '德阳市', '12005', 'area', '12005', '1');
INSERT INTO `sh_cascadedata` VALUES ('19120', '古蔺县', '12004.7', 'area', '12005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19119', '叙永县', '12004.6', 'area', '12005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19118', '合江县', '12004.5', 'area', '12005', '2');
INSERT INTO `sh_cascadedata` VALUES ('19117', '泸　县', '12004.4', 'area', '12004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19116', '龙马潭区', '12004.3', 'area', '12004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19115', '纳溪区', '12004.2', 'area', '12004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19114', '江阳区', '12004.1', 'area', '12004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19113', '泸州市', '12004', 'area', '12004', '1');
INSERT INTO `sh_cascadedata` VALUES ('19112', '盐边县', '12003.5', 'area', '12004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19111', '米易县', '12003.4', 'area', '12003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19110', '仁和区', '12003.3', 'area', '12003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19109', '西　区', '12003.2', 'area', '12003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19108', '东　区', '12003.1', 'area', '12003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19107', '攀枝花市', '12003', 'area', '12003', '1');
INSERT INTO `sh_cascadedata` VALUES ('19106', '富顺县', '12002.6', 'area', '12003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19105', '荣　县', '12002.5', 'area', '12003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19104', '沿滩区', '12002.4', 'area', '12002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19103', '大安区', '12002.3', 'area', '12002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19102', '贡井区', '12002.2', 'area', '12002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19101', '自流井区', '12002.1', 'area', '12002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19100', '自贡市', '12002', 'area', '12002', '1');
INSERT INTO `sh_cascadedata` VALUES ('19099', '崇州市', '12001.19', 'area', '12001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19098', '邛崃市', '12001.18', 'area', '12001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19097', '彭州市', '12001.17', 'area', '12001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19096', '都江堰市', '12001.16', 'area', '12001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19095', '新津县', '12001.15', 'area', '12001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19094', '蒲江县', '12001.14', 'area', '12001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19093', '大邑县', '12001.13', 'area', '12001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19092', '郫　县', '12001.12', 'area', '12001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19091', '双流县', '12001.11', 'area', '12001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19090', '金堂县', '12001.10', 'area', '12001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19089', '温江区', '12001.9', 'area', '12002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19088', '新都区', '12001.8', 'area', '12002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19087', '青白江区', '12001.7', 'area', '12002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19086', '龙泉驿区', '12001.6', 'area', '12002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19085', '成华区', '12001.5', 'area', '12002', '2');
INSERT INTO `sh_cascadedata` VALUES ('19084', '武侯区', '12001.4', 'area', '12001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19083', '金牛区', '12001.3', 'area', '12001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19082', '青羊区', '12001.2', 'area', '12001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19081', '锦江区', '12001.1', 'area', '12001', '2');
INSERT INTO `sh_cascadedata` VALUES ('19080', '成都市', '12001', 'area', '12001', '1');
INSERT INTO `sh_cascadedata` VALUES ('19079', '四川省', '12000', 'area', '12000', '0');
INSERT INTO `sh_cascadedata` VALUES ('19078', '南川市', '11540', 'area', '11540', '1');
INSERT INTO `sh_cascadedata` VALUES ('19077', '永川市', '11539', 'area', '11539', '1');
INSERT INTO `sh_cascadedata` VALUES ('19076', '合川市', '11538', 'area', '11538', '1');
INSERT INTO `sh_cascadedata` VALUES ('19075', '江津市', '11537', 'area', '11537', '1');
INSERT INTO `sh_cascadedata` VALUES ('19074', '彭水苗族土家族自治县', '11536', 'area', '11536', '1');
INSERT INTO `sh_cascadedata` VALUES ('19073', '酉阳土家族苗族自治县', '11535', 'area', '11535', '1');
INSERT INTO `sh_cascadedata` VALUES ('19072', '秀山土家族苗族自治县', '11534', 'area', '11534', '1');
INSERT INTO `sh_cascadedata` VALUES ('19071', '石柱土家族自治县', '11533', 'area', '11533', '1');
INSERT INTO `sh_cascadedata` VALUES ('19070', '巫溪县', '11532', 'area', '11532', '1');
INSERT INTO `sh_cascadedata` VALUES ('19069', '巫山县', '11531', 'area', '11531', '1');
INSERT INTO `sh_cascadedata` VALUES ('19068', '奉节县', '11530', 'area', '11530', '1');
INSERT INTO `sh_cascadedata` VALUES ('19067', '云阳县', '11529', 'area', '11529', '1');
INSERT INTO `sh_cascadedata` VALUES ('19066', '开　县', '11528', 'area', '11528', '1');
INSERT INTO `sh_cascadedata` VALUES ('19065', '忠　县', '11527', 'area', '11527', '1');
INSERT INTO `sh_cascadedata` VALUES ('19064', '武隆县', '11526', 'area', '11526', '1');
INSERT INTO `sh_cascadedata` VALUES ('19063', '垫江县', '11525', 'area', '11525', '1');
INSERT INTO `sh_cascadedata` VALUES ('19062', '丰都县', '11524', 'area', '11524', '1');
INSERT INTO `sh_cascadedata` VALUES ('19061', '城口县', '11523', 'area', '11523', '1');
INSERT INTO `sh_cascadedata` VALUES ('19060', '梁平县', '11522', 'area', '11522', '1');
INSERT INTO `sh_cascadedata` VALUES ('19059', '璧山县', '11521', 'area', '11521', '1');
INSERT INTO `sh_cascadedata` VALUES ('19058', '荣昌县', '11520', 'area', '11520', '1');
INSERT INTO `sh_cascadedata` VALUES ('19057', '大足县', '11519', 'area', '11519', '1');
INSERT INTO `sh_cascadedata` VALUES ('19056', '铜梁县', '11518', 'area', '11518', '1');
INSERT INTO `sh_cascadedata` VALUES ('19055', '潼南县', '11517', 'area', '11517', '1');
INSERT INTO `sh_cascadedata` VALUES ('19054', '綦江县', '11516', 'area', '11516', '1');
INSERT INTO `sh_cascadedata` VALUES ('19053', '长寿区', '11515', 'area', '11515', '1');
INSERT INTO `sh_cascadedata` VALUES ('19052', '黔江区', '11514', 'area', '11514', '1');
INSERT INTO `sh_cascadedata` VALUES ('19051', '巴南区', '11513', 'area', '11513', '1');
INSERT INTO `sh_cascadedata` VALUES ('19050', '渝北区', '11512', 'area', '11512', '1');
INSERT INTO `sh_cascadedata` VALUES ('19049', '双桥区', '11511', 'area', '11511', '1');
INSERT INTO `sh_cascadedata` VALUES ('19048', '万盛区', '11510', 'area', '11510', '1');
INSERT INTO `sh_cascadedata` VALUES ('19047', '北碚区', '11509', 'area', '11509', '1');
INSERT INTO `sh_cascadedata` VALUES ('19046', '南岸区', '11508', 'area', '11508', '1');
INSERT INTO `sh_cascadedata` VALUES ('19045', '九龙坡区', '11507', 'area', '11507', '1');
INSERT INTO `sh_cascadedata` VALUES ('19044', '沙坪坝区', '11506', 'area', '11506', '1');
INSERT INTO `sh_cascadedata` VALUES ('19043', '江北区', '11505', 'area', '11505', '1');
INSERT INTO `sh_cascadedata` VALUES ('19042', '大渡口区', '11504', 'area', '11504', '1');
INSERT INTO `sh_cascadedata` VALUES ('19041', '渝中区', '11503', 'area', '11503', '1');
INSERT INTO `sh_cascadedata` VALUES ('19040', '涪陵区', '11502', 'area', '11502', '1');
INSERT INTO `sh_cascadedata` VALUES ('19039', '万州区', '11501', 'area', '11501', '1');
INSERT INTO `sh_cascadedata` VALUES ('19038', '重庆市', '11500', 'area', '11500', '0');
INSERT INTO `sh_cascadedata` VALUES ('19037', '中沙群岛的岛礁及其海域', '11003.19', 'area', '11003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19036', '南沙群岛', '11003.18', 'area', '11003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19035', '西沙群岛', '11003.17', 'area', '11003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19034', '琼中黎族苗族自治县', '11003.16', 'area', '11003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19033', '保亭黎族苗族自治县', '11003.15', 'area', '11003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19032', '陵水黎族自治县', '11003.14', 'area', '11003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19031', '乐东黎族自治县', '11003.13', 'area', '11003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19030', '昌江黎族自治县', '11003.12', 'area', '11003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19029', '白沙黎族自治县', '11003.11', 'area', '11003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19028', '临高县', '11003.10', 'area', '11003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19027', '澄迈县', '11003.9', 'area', '11004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19026', '屯昌县', '11003.8', 'area', '11004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19025', '定安县', '11003.7', 'area', '11004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19024', '东方市', '11003.6', 'area', '11004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19023', '万宁市', '11003.5', 'area', '11004', '2');
INSERT INTO `sh_cascadedata` VALUES ('19022', '文昌市', '11003.4', 'area', '11003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19021', '儋州市', '11003.3', 'area', '11003', '2');
INSERT INTO `sh_cascadedata` VALUES ('19020', '琼海市', '11003.2', 'area', '11003', '2');

-- -----------------------------
-- Table structure for `sh_category`
-- -----------------------------
DROP TABLE IF EXISTS `sh_category`;
CREATE TABLE `sh_category` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `catname` varchar(255) NOT NULL DEFAULT '' COMMENT '栏目名称',
  `catname1` varchar(255) NOT NULL DEFAULT '' COMMENT '栏目副标题',
  `catdir` varchar(30) NOT NULL DEFAULT '' COMMENT '栏目目录',
  `parentdir` varchar(50) NOT NULL DEFAULT '',
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '父级id',
  `moduleid` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '模型表id',
  `module` char(24) NOT NULL DEFAULT '',
  `arrparentid` varchar(100) NOT NULL DEFAULT '' COMMENT '所有父类的id',
  `arrchildid` varchar(100) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(150) NOT NULL DEFAULT '' COMMENT 'SEO标题',
  `keywords` varchar(200) NOT NULL DEFAULT '' COMMENT 'SEO关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT 'SEO描述',
  `orderid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ishtml` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ismenu` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否导航',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `picurl` varchar(100) NOT NULL DEFAULT '',
  `child` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `url` varchar(100) NOT NULL DEFAULT '' COMMENT 'url链接',
  `template_category` varchar(50) NOT NULL DEFAULT '',
  `template_list` varchar(50) NOT NULL DEFAULT '',
  `template_show` varchar(50) NOT NULL DEFAULT '',
  `pagesize` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `readgroup` varchar(100) NOT NULL DEFAULT '' COMMENT '访问权限',
  `listtype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `createtime` int(10) NOT NULL,
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`),
  KEY `listorder` (`orderid`)
) ENGINE=MyISAM AUTO_INCREMENT=132 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_category`
-- -----------------------------
INSERT INTO `sh_category` VALUES ('8', '走进维思得', '', '', '/', '0', '26', 'page', '0', '8,65,57,56,55,54,53,52', '0', '教育', '顶尖教育', '教育1', '2', '0', '1', '0', '', '1', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('93', '小升初冲刺课程', '', '', '/', '86', '26', 'page', '0,85,86', '', '0', '', '', '', '29', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('94', '初中课程', '', '', '/', '86', '26', 'page', '0,85,86', '', '0', '', '', '', '30', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('95', '高中课程', '', '', '/', '86', '26', 'page', '0,85,86', '', '0', '', '', '', '31', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('92', '小学课程', '', '', '/', '86', '26', 'page', '0,85,86', '', '0', '', '', '', '28', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('90', '绘本阅读课程', '', '', '/', '86', '26', 'page', '0,85,86', '', '0', '', '', '', '26', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('91', '儿童英语课程', '', '', '/', '86', '26', 'page', '0,85,86', '', '0', '', '', '', '27', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('89', '寒暑假针对课程', '', '', '/', '85', '26', 'page', '0,85', '', '0', '', '', '', '25', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('88', '雅思等出国系列课程', '', '', '/', '85', '26', 'page', '0,85', '', '0', '', '', '', '24', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('82', '教学成果', '', '', '/', '8', '26', 'page', '0,8', '', '0', '', '', '教学成果', '19', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('83', '所获荣誉', '', '', '/', '8', '26', 'page', '0,8', '', '0', '', '', '所获荣誉', '20', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('84', '教学科研', '', '', '/', '8', '26', 'page', '0,8', '', '0', '', '', '教学科研', '21', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('85', '课程体系', '', '', '/', '0', '26', 'page', '0', '', '0', '', '', '', '2', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('86', '常规课程', '', '', '/', '85', '26', 'page', '0,85', '', '0', '', '', '', '22', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('87', 'VIP课程', '', '', '/', '85', '26', 'page', '0,85', '', '0', '', '', '', '23', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('80', '教师团队', '', '', '/', '8', '26', 'page', '0,8', '', '0', '', '', '教师团队', '22', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('81', '教师环境', '', '', '/', '8', '26', 'page', '0,8', '', '0', '', '', '教师环境', '18', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('75', '文章栏目', '', '', '/', '0', '24', 'news', '0', '', '0', '', '', '文章栏目', '13', '0', '1', '0', '', '0', '', '', 'list_article', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('76', '学员展示', '', '', '/', '0', '25', 'picurl', '0', '', '0', '', '', '图片表', '14', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('79', '管理团队', '', '', '/', '8', '26', 'page', '0,8', '', '0', '', '', '管理团队', '17', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('71', '测试栏目', 'test', '', '/', '0', '22', 'test1', '0', '', '0', '', '', '测试栏目', '12', '0', '0', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('96', '活动通知', '', '', '/', '75', '24', 'news', '0,75', '', '0', '', '', '', '32', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('97', '通知公告', '', '', '/', '75', '24', 'news', '0,75', '', '0', '', '', '', '33', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('98', '活动展示', '', '', '/', '76', '25', 'picurl', '0,76', '', '0', '', '', '', '34', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('99', '英语娱乐', '', '', '/', '76', '25', 'picurl', '0,76', '', '0', '', '', '', '35', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('100', '优秀学员', '', '', '/', '76', '25', 'picurl', '0,76', '', '0', '', '', '', '36', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('101', '活动视频', '', '', '/', '98', '25', 'picurl', '0,76,98', '', '0', '', '', '', '37', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('102', '获奖作品展示', '', '', '/', '98', '25', 'picurl', '0,76,98', '', '0', '', '', '', '38', '0', '1', '0', '', '0', '', '', '', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('116', '视频展示', '', '', '/', '115', '25', 'picurl', '0,115', '', '0', '', '', '', '40', '0', '1', '0', '', '0', '', '', 'excellent_details', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('115', '视频中心', '', '', '/', '0', '25', 'picurl', '0', '', '0', '', '', '', '39', '0', '1', '0', '', '0', '', '', 'excellent', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('117', '学习中心', '', '', '/', '0', '25', 'picurl', '0', '', '0', '', '', '', '41', '0', '1', '0', '', '0', '', '', 'student', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('118', '学习中心', '', '', '/', '117', '25', 'picurl', '0,117', '', '0', '', '', '', '42', '0', '1', '0', '', '0', '', '', 'student', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('119', '留言中心', '', '', '/', '0', '26', 'page', '0', '', '0', '', '', '', '43', '0', '1', '0', '', '0', '', '', 'message', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('120', '联系我们', '', '', '/', '0', '26', 'page', '0', '', '0', '', '', '', '44', '0', '1', '0', '', '0', '', '', 'contact', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('121', '招贤纳士', '', '', '/', '120', '24', 'news', '0,120', '', '0', '', '', '', '45', '0', '1', '0', '', '0', '', '', 'recruit', '', '0', '', '0', '0', '0');
INSERT INTO `sh_category` VALUES ('122', '联系方式', '', '', '/', '120', '26', 'page', '0,120', '', '0', '', '', '', '46', '0', '1', '0', '', '0', '', '', 'contact', '', '0', '', '0', '0', '0');

-- -----------------------------
-- Table structure for `sh_field`
-- -----------------------------
DROP TABLE IF EXISTS `sh_field`;
CREATE TABLE `sh_field` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `moduleid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `field` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(30) NOT NULL DEFAULT '',
  `tips` varchar(150) NOT NULL DEFAULT '',
  `required` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `minlength` int(10) unsigned NOT NULL DEFAULT '0',
  `maxlength` int(10) unsigned NOT NULL DEFAULT '0',
  `pattern` varchar(255) NOT NULL DEFAULT '',
  `errormsg` varchar(255) NOT NULL DEFAULT '',
  `class` varchar(20) NOT NULL DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT '',
  `setup` mediumtext NOT NULL,
  `ispost` tinyint(1) NOT NULL DEFAULT '0',
  `unpostgroup` varchar(60) NOT NULL DEFAULT '',
  `orderid` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=269 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_field`
-- -----------------------------
INSERT INTO `sh_field` VALUES ('220', '24', 'posttime', '更新时间', '', '0', '1', '11', '', '', '', 'datetime', '', '1', '', '12', '1', '1');
INSERT INTO `sh_field` VALUES ('221', '24', 'checkinfo', '审核状态', '', '0', '1', '11', '', '', '', 'radio', 'array (\n  \'options\' => \'审核|1,未审|0\',\n  \'fieldtype\' => \'tinyint\',\n  \'numbertype\' => \'1\',\n  \'default\' => \'\',\n)', '1', '', '13', '1', '1');
INSERT INTO `sh_field` VALUES ('219', '24', 'orderid', '排列排序', '', '0', '1', '11', '', '', '', 'number', 'array (\n \'numbertype\' => \'1\',\'decimaldigits\' => \'0\',\'default\' => \'\', \n)', '1', '', '11', '1', '1');
INSERT INTO `sh_field` VALUES ('218', '24', 'hits', '点击次数', '', '0', '1', '11', '', '', '', 'number', 'array (\n \'numbertype\' => \'1\',\'decimaldigits\' => \'0\',\'default\' => \'\', \n)', '1', '', '10', '1', '1');
INSERT INTO `sh_field` VALUES ('217', '24', 'picarr', '组图', '', '0', '0', '0', '', '', '', 'images', 'array (\n \'upload_allowext\' => \'jpg|jpeg|gif|png\', \n)', '1', '', '9', '1', '1');
INSERT INTO `sh_field` VALUES ('215', '24', 'content', '详细内容', '', '0', '0', '0', '', '', '', 'editor', 'array (\n \'edittype\' => \'UEditor\',\n)', '1', '', '7', '1', '1');
INSERT INTO `sh_field` VALUES ('216', '24', 'picurl', '缩略图', '', '0', '1', '100', '', '', '', 'image', 'array (\n \'upload_allowext\' => \'jpg|jpeg|gif|png\', \n)', '1', '', '8', '1', '1');
INSERT INTO `sh_field` VALUES ('214', '24', 'description', '摘要', '', '0', '0', '0', '', '', '', 'textarea', 'array (\n \'fieldtype\' => \'mediumtext\',\'default\' => \'\', \n )', '1', '', '6', '1', '1');
INSERT INTO `sh_field` VALUES ('212', '24', 'linkurl', '跳转链接', '', '0', '1', '255', '', '', '', 'title', 'array (\n \'default\' => \'\',\'ispassword\' => \'0\',\'fieldtype\' => \'varchar\',\n)', '1', '', '4', '1', '1');
INSERT INTO `sh_field` VALUES ('213', '24', 'keywords', '关键词', '', '0', '1', '50', '', '', '', 'title', 'array (\n \'default\' => \'\',\'ispassword\' => \'0\',\'fieldtype\' => \'varchar\',\n)', '1', '', '5', '1', '1');
INSERT INTO `sh_field` VALUES ('210', '24', 'source', '文章来源', '', '0', '1', '50', '', '', '', 'title', 'array (\n \'default\' => \'\',\'ispassword\' => \'0\',\'fieldtype\' => \'varchar\',\n)', '1', '', '2', '1', '1');
INSERT INTO `sh_field` VALUES ('242', '26', 'picurl', '缩略图', '', '0', '0', '0', '', '', 'picurl', 'image', 'array (\n  \'upload_allowext\' => \'jpg|jpeg|gif|png\',\n)', '0', '', '8', '1', '0');
INSERT INTO `sh_field` VALUES ('211', '24', 'author', '作者编辑', '', '0', '1', '50', '', '', '', 'title', 'array (\n \'default\' => \'\',\'ispassword\' => \'0\',\'fieldtype\' => \'varchar\',\n)', '1', '', '3', '1', '1');
INSERT INTO `sh_field` VALUES ('209', '24', 'title', '标题', '', '1', '1', '80', '', '', '', 'title', 'array (\n \'default\' => \'\',\'ispassword\' => \'0\',\'fieldtype\' => \'varchar\',\n)', '1', '', '1', '1', '1');
INSERT INTO `sh_field` VALUES ('241', '26', 'checkinfo', '审核状态', '', '0', '1', '11', '', '', '', 'radio', 'array (\n  \'options\' => \'审核|1,未审|0\',\n  \'fieldtype\' => \'tinyint\',\n  \'numbertype\' => \'1\',\n  \'default\' => \'\',\n)', '1', '', '13', '1', '1');
INSERT INTO `sh_field` VALUES ('226', '25', 'keywords', '关键词', '', '0', '1', '50', '', '', '', 'title', 'array (\n \'default\' => \'\',\'ispassword\' => \'0\',\'fieldtype\' => \'varchar\',\n)', '1', '', '5', '1', '1');
INSERT INTO `sh_field` VALUES ('227', '25', 'description', '摘要', '', '0', '0', '0', '', '', '', 'textarea', 'array (\n \'fieldtype\' => \'mediumtext\',\'default\' => \'\', \n )', '1', '', '6', '1', '1');
INSERT INTO `sh_field` VALUES ('228', '25', 'content', '详细内容', '', '0', '0', '0', '', '', '', 'editor', 'array (\n \'edittype\' => \'UEditor\',\n)', '1', '', '7', '1', '1');
INSERT INTO `sh_field` VALUES ('229', '25', 'picurl', '缩略图', '', '0', '1', '100', '', '', '', 'image', 'array (\n \'upload_allowext\' => \'jpg|jpeg|gif|png\', \n)', '1', '', '8', '1', '1');
INSERT INTO `sh_field` VALUES ('230', '25', 'picarr', '组图', '', '0', '0', '0', '', '', '', 'images', 'array (\n \'upload_allowext\' => \'jpg|jpeg|gif|png\', \n)', '1', '', '9', '1', '1');
INSERT INTO `sh_field` VALUES ('231', '25', 'hits', '点击次数', '', '0', '1', '11', '', '', '', 'number', 'array (\n \'numbertype\' => \'1\',\'decimaldigits\' => \'0\',\'default\' => \'\', \n)', '1', '', '10', '1', '1');
INSERT INTO `sh_field` VALUES ('232', '25', 'orderid', '排列排序', '', '0', '1', '11', '', '', '', 'number', 'array (\n \'numbertype\' => \'1\',\'decimaldigits\' => \'0\',\'default\' => \'\', \n)', '1', '', '11', '1', '1');
INSERT INTO `sh_field` VALUES ('233', '25', 'posttime', '更新时间', '', '0', '1', '11', '', '', '', 'datetime', '', '1', '', '12', '1', '1');
INSERT INTO `sh_field` VALUES ('234', '25', 'checkinfo', '审核状态', '', '0', '1', '11', '', '', '', 'radio', 'array (\n  \'options\' => \'审核|1,未审|0\',\n  \'fieldtype\' => \'tinyint\',\n  \'numbertype\' => \'1\',\n  \'default\' => \'\',\n)', '1', '', '13', '1', '1');
INSERT INTO `sh_field` VALUES ('235', '26', 'title', '标题', '', '1', '1', '80', '', '', '', 'title', 'array (\n \'default\' => \'\',\'ispassword\' => \'0\',\'fieldtype\' => \'varchar\',\n)', '1', '', '1', '1', '1');
INSERT INTO `sh_field` VALUES ('236', '26', 'linkurl', '跳转链接', '', '0', '1', '255', '', '', '', 'title', 'array (\n \'default\' => \'\',\'ispassword\' => \'0\',\'fieldtype\' => \'varchar\',\n)', '1', '', '4', '1', '1');
INSERT INTO `sh_field` VALUES ('237', '26', 'content', '详细内容', '', '0', '0', '0', '', '', '', 'editor', 'array (\n \'edittype\' => \'UEditor\',\n)', '1', '', '7', '1', '1');
INSERT INTO `sh_field` VALUES ('238', '26', 'hits', '点击次数', '', '0', '1', '11', '', '', '', 'number', 'array (\n \'numbertype\' => \'1\',\'decimaldigits\' => \'0\',\'default\' => \'\', \n)', '1', '', '10', '1', '1');
INSERT INTO `sh_field` VALUES ('239', '26', 'orderid', '排列排序', '', '0', '1', '11', '', '', '', 'number', 'array (\n \'numbertype\' => \'1\',\'decimaldigits\' => \'0\',\'default\' => \'\', \n)', '1', '', '11', '1', '1');
INSERT INTO `sh_field` VALUES ('240', '26', 'posttime', '更新时间', '', '0', '1', '11', '', '', '', 'datetime', '', '1', '', '12', '1', '1');
INSERT INTO `sh_field` VALUES ('225', '25', 'linkurl', '跳转链接', '', '0', '1', '255', '', '', '', 'title', 'array (\n \'default\' => \'\',\'ispassword\' => \'0\',\'fieldtype\' => \'varchar\',\n)', '1', '', '4', '1', '1');
INSERT INTO `sh_field` VALUES ('224', '25', 'author', '作者编辑', '', '0', '1', '50', '', '', '', 'title', 'array (\n \'default\' => \'\',\'ispassword\' => \'0\',\'fieldtype\' => \'varchar\',\n)', '1', '', '3', '1', '1');
INSERT INTO `sh_field` VALUES ('222', '25', 'title', '标题', '', '1', '1', '80', '', '', '', 'title', 'array (\n \'default\' => \'\',\'ispassword\' => \'0\',\'fieldtype\' => \'varchar\',\n)', '1', '', '1', '1', '1');
INSERT INTO `sh_field` VALUES ('223', '25', 'source', '文章来源', '', '0', '1', '50', '', '', '', 'title', 'array (\n \'default\' => \'\',\'ispassword\' => \'0\',\'fieldtype\' => \'varchar\',\n)', '1', '', '2', '1', '1');
INSERT INTO `sh_field` VALUES ('193', '22', 'wenjian', '文件上传', '', '0', '0', '0', '', '', 'wenjian', 'file', 'array (\n  \'upload_allowext\' => \'zip|rar|doc|ppt\',\n)', '0', '', '121', '1', '0');
INSERT INTO `sh_field` VALUES ('195', '22', 'picarr2', '组图2', '', '0', '0', '0', '', '', 'picarr2', 'images', 'array (\n  \'upload_allowext\' => \'jpg|jpeg|gif|png\',\n)', '0', '', '122', '1', '0');
INSERT INTO `sh_field` VALUES ('190', '22', 'lian', '联动菜单', '', '0', '0', '0', '', '', 'lian', 'linkage', '', '0', '', '120', '1', '0');
INSERT INTO `sh_field` VALUES ('189', '22', 'danxia', '单选下拉', '', '0', '0', '0', '', '', 'danxia', 'select', 'array (\n  \'options\' => \'单选下拉1|1,单选下拉2|2,单选下拉3|3\',\n  \'multiple\' => \'1\',\n  \'fieldtype\' => \'int\',\n  \'numbertype\' => \'1\',\n  \'size\' => \'\',\n  \'default\' => \'\',\n)', '0', '', '119', '1', '0');
INSERT INTO `sh_field` VALUES ('187', '22', 'riqi', '日期', '', '0', '0', '0', '', '', 'riqi', 'datetime', '', '0', '', '117', '1', '0');
INSERT INTO `sh_field` VALUES ('186', '22', 'shuzi', '小数数字', '', '0', '0', '0', '', '', 'shuzi', 'number', 'array (\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'2\',\n  \'default\' => \'\',\n)', '0', '', '116', '1', '0');
INSERT INTO `sh_field` VALUES ('185', '22', 'fuxuan', '复选框', '', '0', '0', '0', '', '', 'fuxuan', 'checkbox', 'array (\n  \'options\' => \'复选框1|1,复选框2|2,复选框3|3,复选框4|4\',\n  \'fieldtype\' => \'varchar\',\n  \'numbertype\' => \'1\',\n  \'default\' => \'\',\n)', '0', '', '115', '1', '0');
INSERT INTO `sh_field` VALUES ('184', '22', 'content2', '详细内容2', '', '0', '0', '0', '', '', 'content2', 'editor', 'array (\n  \'edittype\' => \'UEditor\',\n)', '0', '', '114', '1', '0');
INSERT INTO `sh_field` VALUES ('188', '22', 'duoxuan', '下拉多选', '', '0', '0', '0', '', '', 'duoxuan', 'select', 'array (\n  \'options\' => \'多选1|1,多选2|2,多选3|3,多选4|4\',\n  \'multiple\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n  \'numbertype\' => \'1\',\n  \'size\' => \'\',\n  \'default\' => \'\',\n)', '0', '', '118', '1', '0');
INSERT INTO `sh_field` VALUES ('180', '22', 'checkinfo', '审核状态', '', '0', '1', '11', '', '', '', 'radio', 'array (\n \'options\' => \'审核|1,未审|0\',\'fieldtype\' => \'tinyint\',\'numbertype\' => \'1\',\'default\' => \'\',\n)', '1', '', '14', '1', '1');
INSERT INTO `sh_field` VALUES ('179', '22', 'posttime', '更新时间', '', '0', '1', '11', '', '', '', 'datetime', '', '1', '', '12', '1', '1');
INSERT INTO `sh_field` VALUES ('178', '22', 'orderid', '排列排序', '', '0', '1', '11', '', '', '', 'number', 'array (\n \'numbertype\' => \'1\',\'decimaldigits\' => \'0\',\'default\' => \'\', \n)', '1', '', '11', '1', '1');
INSERT INTO `sh_field` VALUES ('177', '22', 'hits', '点击次数', '', '0', '1', '11', '', '', '', 'number', 'array (\n \'numbertype\' => \'1\',\'decimaldigits\' => \'0\',\'default\' => \'\', \n)', '1', '', '10', '1', '1');
INSERT INTO `sh_field` VALUES ('181', '22', 'picurl', '缩略图', '', '0', '0', '100', '', '', 'picurl', 'image', 'array (\n  \'upload_allowext\' => \'jpg|jpeg|gif|png\',\n)', '0', '', '4', '1', '0');
INSERT INTO `sh_field` VALUES ('182', '22', 'picarr', '组图', '', '0', '0', '0', '', '', 'picarr', 'images', 'array (\n  \'upload_allowext\' => \'jpg|jpeg|gif|png\',\n)', '0', '', '112', '1', '0');
INSERT INTO `sh_field` VALUES ('183', '22', 'content', '详细信息', '', '0', '0', '0', '', '', 'content', 'editor', 'array (\n  \'edittype\' => \'layedit\',\n)', '0', '', '113', '1', '0');
INSERT INTO `sh_field` VALUES ('173', '22', 'description', '摘要', '', '0', '0', '0', '', '', '', 'textarea', 'array (\n \'fieldtype\' => \'mediumtext\',\'default\' => \'\', \n)', '1', '', '7', '1', '1');
INSERT INTO `sh_field` VALUES ('172', '22', 'keywords', '关键词', '', '0', '1', '50', '', '', '', 'title', 'array (\n \'default\' => \'\',\'ispassword\' => \'0\',\'fieldtype\' => \'varchar\',\n)', '1', '', '6', '1', '1');
INSERT INTO `sh_field` VALUES ('171', '22', 'linkurl', '跳转链接', '', '0', '1', '255', '', '', '', 'title', 'array (\n \'default\' => \'\',\'ispassword\' => \'0\',\'fieldtype\' => \'varchar\',\n)', '1', '', '5', '1', '1');
INSERT INTO `sh_field` VALUES ('170', '22', 'author', '作者编辑', '', '0', '1', '50', '', '', '', 'title', 'array (\n \'default\' => \'\',\'ispassword\' => \'0\',\'fieldtype\' => \'varchar\',\n)', '1', '', '3', '1', '1');
INSERT INTO `sh_field` VALUES ('169', '22', 'source', '文章来源', '', '0', '1', '50', '', '', '', 'title', 'array (\n \'default\' => \'\',\'ispassword\' => \'0\',\'fieldtype\' => \'varchar\',\n)', '1', '', '2', '1', '1');
INSERT INTO `sh_field` VALUES ('168', '22', 'title', '标题', '', '1', '1', '80', '', '', '', 'title', 'array (\n \'default\' => \'\',\'ispassword\' => \'0\',\'fieldtype\' => \'varchar\',\n)', '1', '', '1', '1', '1');

-- -----------------------------
-- Table structure for `sh_getmode`
-- -----------------------------
DROP TABLE IF EXISTS `sh_getmode`;
CREATE TABLE `sh_getmode` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '货到方式id',
  `classname` varchar(30) NOT NULL COMMENT '货到方式名称',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_getmode`
-- -----------------------------
INSERT INTO `sh_getmode` VALUES ('1', '送货上门', '1', 'true');
INSERT INTO `sh_getmode` VALUES ('2', '用户自取', '2', 'true');

-- -----------------------------
-- Table structure for `sh_goodsattr`
-- -----------------------------
DROP TABLE IF EXISTS `sh_goodsattr`;
CREATE TABLE `sh_goodsattr` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品属性id',
  `goodsid` smallint(5) unsigned NOT NULL COMMENT '所属分类',
  `attrname` varchar(30) NOT NULL COMMENT '属性名称',
  `orderid` mediumint(8) unsigned NOT NULL COMMENT '排列排序',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_goodsattr`
-- -----------------------------
INSERT INTO `sh_goodsattr` VALUES ('1', '10', '颜色', '1', 'true');
INSERT INTO `sh_goodsattr` VALUES ('2', '10', '型号', '2', 'true');

-- -----------------------------
-- Table structure for `sh_goodsbrand`
-- -----------------------------
DROP TABLE IF EXISTS `sh_goodsbrand`;
CREATE TABLE `sh_goodsbrand` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品品牌id',
  `parentid` mediumint(8) unsigned NOT NULL COMMENT '品牌上级id',
  `parentstr` varchar(50) NOT NULL COMMENT '品牌上级id字符串',
  `classname` varchar(30) NOT NULL COMMENT '品牌名称',
  `picurl` varchar(100) NOT NULL COMMENT '缩略图片',
  `linkurl` varchar(255) NOT NULL COMMENT '跳转链接',
  `orderid` mediumint(10) unsigned NOT NULL COMMENT '排列排序',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `sh_goodsflag`
-- -----------------------------
DROP TABLE IF EXISTS `sh_goodsflag`;
CREATE TABLE `sh_goodsflag` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品标记id',
  `flag` varchar(30) NOT NULL COMMENT '标记名称',
  `flagname` varchar(30) NOT NULL COMMENT '标记标识',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_goodsflag`
-- -----------------------------
INSERT INTO `sh_goodsflag` VALUES ('1', 'c', '推荐', '1');
INSERT INTO `sh_goodsflag` VALUES ('2', 'f', '幻灯', '2');
INSERT INTO `sh_goodsflag` VALUES ('3', 'a', '特推', '3');
INSERT INTO `sh_goodsflag` VALUES ('4', 't', '特价', '4');
INSERT INTO `sh_goodsflag` VALUES ('5', 'h', '热卖', '5');

-- -----------------------------
-- Table structure for `sh_goodsorder`
-- -----------------------------
DROP TABLE IF EXISTS `sh_goodsorder`;
CREATE TABLE `sh_goodsorder` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品订单id',
  `username` varchar(30) NOT NULL COMMENT '会员用户名',
  `attrstr` text NOT NULL COMMENT '商品列表',
  `truename` varchar(30) NOT NULL COMMENT '收货人姓名',
  `telephone` varchar(30) NOT NULL COMMENT '电话',
  `idcard` varchar(30) NOT NULL COMMENT '证件号码',
  `zipcode` varchar(30) NOT NULL COMMENT '邮编',
  `postarea_prov` varchar(10) NOT NULL COMMENT '配送地区_省',
  `postarea_city` varchar(10) NOT NULL COMMENT '配送地区_市',
  `postarea_country` varchar(10) NOT NULL COMMENT '配送地区_县',
  `address` varchar(80) NOT NULL COMMENT '地址',
  `postmode` smallint(5) NOT NULL COMMENT '配送方式',
  `paymode` smallint(5) NOT NULL COMMENT '支付方式',
  `getmode` smallint(5) NOT NULL COMMENT '货到方式',
  `ordernum` varchar(30) NOT NULL COMMENT '订单号',
  `postid` varchar(30) NOT NULL COMMENT '运单号',
  `weight` varchar(10) NOT NULL COMMENT '物品重量',
  `cost` varchar(10) NOT NULL COMMENT '商品运费',
  `amount` varchar(10) NOT NULL COMMENT '订单金额',
  `integral` smallint(5) unsigned NOT NULL COMMENT '积分点数',
  `buyremark` text NOT NULL COMMENT '购物备注',
  `sendremark` text NOT NULL COMMENT '发货方备注',
  `posttime` int(10) unsigned NOT NULL COMMENT '订单时间',
  `orderid` mediumint(10) unsigned NOT NULL COMMENT '排列排序',
  `checkinfo` varchar(255) NOT NULL COMMENT '审核状态',
  `core` set('true') NOT NULL COMMENT '是否加星',
  `delstate` set('true') NOT NULL COMMENT '删除状态',
  `deltime` int(10) unsigned NOT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `sh_goodstype`
-- -----------------------------
DROP TABLE IF EXISTS `sh_goodstype`;
CREATE TABLE `sh_goodstype` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品类型id',
  `parentid` mediumint(8) unsigned NOT NULL COMMENT '类型上级id',
  `parentstr` varchar(50) NOT NULL COMMENT '类型上级id字符串',
  `classname` varchar(30) NOT NULL COMMENT '类别名称',
  `picurl` varchar(255) DEFAULT NULL COMMENT '缩略图片',
  `linkurl` varchar(255) DEFAULT NULL COMMENT '跳转链接',
  `orderid` mediumint(8) unsigned NOT NULL COMMENT '排列顺序',
  `checkinfo` enum('true','false') NOT NULL COMMENT '隐藏类别',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_goodstype`
-- -----------------------------
INSERT INTO `sh_goodstype` VALUES ('1', '0', '0,', '手机通讯', '', '', '1', 'true');
INSERT INTO `sh_goodstype` VALUES ('2', '0', '0,', '电脑笔记本', '', '', '2', 'true');
INSERT INTO `sh_goodstype` VALUES ('3', '0', '0,', '相机 摄相机', '', '', '3', 'true');
INSERT INTO `sh_goodstype` VALUES ('4', '0', '0,', '随身视听', '', '', '4', 'true');
INSERT INTO `sh_goodstype` VALUES ('5', '0', '0,', '电脑外设', '', '', '5', 'true');
INSERT INTO `sh_goodstype` VALUES ('6', '0', '0,', 'DIY装机', '', '', '6', 'true');
INSERT INTO `sh_goodstype` VALUES ('7', '0', '0,', '办公用品', '', '', '7', 'true');
INSERT INTO `sh_goodstype` VALUES ('8', '1', '0,1,', '通讯产品', '', '', '8', 'true');
INSERT INTO `sh_goodstype` VALUES ('9', '1', '0,1,', '手机配件', '', '', '9', 'true');
INSERT INTO `sh_goodstype` VALUES ('10', '1', '0,1,', '手机', '', '', '10', 'true');
INSERT INTO `sh_goodstype` VALUES ('11', '2', '0,2,', '电脑整机', '', '', '11', 'true');
INSERT INTO `sh_goodstype` VALUES ('12', '2', '0,2,', '笔记本', '', '', '12', 'true');
INSERT INTO `sh_goodstype` VALUES ('13', '2', '0,2,', '电脑配件', '', '', '13', 'true');
INSERT INTO `sh_goodstype` VALUES ('14', '3', '0,3,', '相机配件', '', '', '14', 'true');
INSERT INTO `sh_goodstype` VALUES ('15', '3', '0,3,', '数码摄相机', '', '', '15', 'true');
INSERT INTO `sh_goodstype` VALUES ('16', '3', '0,3,', '数码相机', '', '', '16', 'true');
INSERT INTO `sh_goodstype` VALUES ('17', '4', '0,4,', '电子阅读', '', '', '17', 'true');
INSERT INTO `sh_goodstype` VALUES ('18', '4', '0,4,', 'MID', '', '', '18', 'true');
INSERT INTO `sh_goodstype` VALUES ('19', '4', '0,4,', 'MP3|MP4', '', '', '19', 'true');
INSERT INTO `sh_goodstype` VALUES ('20', '5', '0,5,', '移动硬盘', '', '', '20', 'true');
INSERT INTO `sh_goodstype` VALUES ('21', '5', '0,5,', '键盘', '', '', '21', 'true');
INSERT INTO `sh_goodstype` VALUES ('22', '5', '0,5,', '鼠标', '', '', '22', 'true');
INSERT INTO `sh_goodstype` VALUES ('23', '6', '0,6,', '扩展配件', '', '', '23', 'true');
INSERT INTO `sh_goodstype` VALUES ('24', '6', '0,6,', '装机配件', '', '', '24', 'true');
INSERT INTO `sh_goodstype` VALUES ('25', '6', '0,6,', '显示器', '', '', '25', 'true');
INSERT INTO `sh_goodstype` VALUES ('26', '7', '0,7,', '投影显示', '', '', '26', 'true');
INSERT INTO `sh_goodstype` VALUES ('27', '7', '0,7,', '办公打印', '', '', '27', 'true');

-- -----------------------------
-- Table structure for `sh_infoflag`
-- -----------------------------
DROP TABLE IF EXISTS `sh_infoflag`;
CREATE TABLE `sh_infoflag` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '信息标记id',
  `flag` varchar(30) NOT NULL COMMENT '标记名称',
  `flagname` varchar(30) NOT NULL COMMENT '标记标识',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_infoflag`
-- -----------------------------
INSERT INTO `sh_infoflag` VALUES ('1', 'n', '特荐', '1');
INSERT INTO `sh_infoflag` VALUES ('2', 'h', '头条', '2');
INSERT INTO `sh_infoflag` VALUES ('3', 'c', '推荐', '3');
INSERT INTO `sh_infoflag` VALUES ('4', 'a', '猜你感兴趣', '4');
INSERT INTO `sh_infoflag` VALUES ('5', 's', '滚动', '5');
INSERT INTO `sh_infoflag` VALUES ('6', 'j', '跳转', '6');
INSERT INTO `sh_infoflag` VALUES ('7', '7', '图片', '7');

-- -----------------------------
-- Table structure for `sh_member`
-- -----------------------------
DROP TABLE IF EXISTS `sh_member`;
CREATE TABLE `sh_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `level` int(10) NOT NULL COMMENT '等级id',
  `username` varchar(32) NOT NULL COMMENT '用户名',
  `password` varchar(32) NOT NULL COMMENT '密码',
  `question` varchar(50) NOT NULL COMMENT '提问',
  `answer` varchar(50) NOT NULL COMMENT '回答',
  `cnname` varchar(10) NOT NULL COMMENT '姓名',
  `enname` varchar(20) NOT NULL COMMENT '英文名',
  `avatar` varchar(100) NOT NULL COMMENT '头像',
  `sex` tinyint(1) unsigned NOT NULL COMMENT '性别',
  `birthtype` tinyint(1) unsigned NOT NULL COMMENT '生日类型',
  `birth_year` varchar(10) NOT NULL DEFAULT '-1' COMMENT '生日_年',
  `birth_month` varchar(10) NOT NULL DEFAULT '-1' COMMENT '生日_月',
  `birth_day` varchar(10) NOT NULL DEFAULT '-1' COMMENT '生日_日',
  `astro` varchar(10) NOT NULL DEFAULT '-1' COMMENT '星座',
  `bloodtype` tinyint(2) NOT NULL DEFAULT '-1' COMMENT '血型',
  `trade` varchar(10) NOT NULL DEFAULT '-1' COMMENT '行业',
  `live_prov` varchar(10) NOT NULL DEFAULT '-1' COMMENT '现居地_省',
  `live_city` varchar(10) NOT NULL DEFAULT '-1' COMMENT '现居地_市',
  `live_dist` varchar(15) NOT NULL DEFAULT '-1' COMMENT '现居地_区',
  `cardtype` tinyint(2) NOT NULL DEFAULT '-1' COMMENT '证件类型',
  `cardnum` varchar(32) NOT NULL COMMENT '证件号码',
  `intro` text NOT NULL COMMENT '个人说明',
  `email` varchar(40) NOT NULL COMMENT '电子邮件',
  `qqnum` varchar(20) NOT NULL COMMENT 'QQ号码',
  `mobile` varchar(20) NOT NULL COMMENT '手机',
  `telephone` varchar(20) NOT NULL COMMENT '固定电话',
  `address` varchar(100) NOT NULL COMMENT '通信地址',
  `zipcode` varchar(10) NOT NULL COMMENT '邮编',
  `enteruser` set('1') NOT NULL COMMENT '认证',
  `expval` int(10) NOT NULL COMMENT '经验值',
  `integral` int(10) unsigned NOT NULL COMMENT '积分',
  `regtime` int(10) unsigned NOT NULL COMMENT '注册时间',
  `regip` varchar(20) NOT NULL COMMENT '注册IP',
  `logintime` int(10) unsigned NOT NULL COMMENT '登陆时间',
  `loginip` varchar(20) NOT NULL COMMENT '登陆IP',
  `status` int(4) NOT NULL DEFAULT '0' COMMENT '状态 0=开启，1=关闭',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_member`
-- -----------------------------
INSERT INTO `sh_member` VALUES ('5', '1', '唐寅', '', '', '', '', '', '', '0', '0', '-1', '-1', '-1', '-1', '-1', '-1', '浙江', '杭州', '西湖区', '-1', '', '', 'cicicoco321@163.com', '', '18668047515', '', '', '', '', '0', '0', '1515134206', '', '0', '', '0');

-- -----------------------------
-- Table structure for `sh_member_level`
-- -----------------------------
DROP TABLE IF EXISTS `sh_member_level`;
CREATE TABLE `sh_member_level` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT COMMENT '表id',
  `level_name` varchar(30) DEFAULT NULL COMMENT '头衔名称',
  `orderid` int(3) DEFAULT '0' COMMENT '排序',
  `bomlimit` int(5) DEFAULT '0' COMMENT '积分下限',
  `toplimit` int(5) DEFAULT '0' COMMENT '积分上限',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_member_level`
-- -----------------------------
INSERT INTO `sh_member_level` VALUES ('1', '注册会员', '1', '0', '500');
INSERT INTO `sh_member_level` VALUES ('2', '铜牌会员', '2', '501', '1000');
INSERT INTO `sh_member_level` VALUES ('3', '白银会员', '3', '1001', '2000');
INSERT INTO `sh_member_level` VALUES ('4', '黄金会员', '4', '2001', '3500');
INSERT INTO `sh_member_level` VALUES ('5', '钻石会员', '5', '3501', '5500');
INSERT INTO `sh_member_level` VALUES ('6', '超级VIP', '6', '5501', '99999');

-- -----------------------------
-- Table structure for `sh_message`
-- -----------------------------
DROP TABLE IF EXISTS `sh_message`;
CREATE TABLE `sh_message` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '留言id',
  `siteid` smallint(5) NOT NULL DEFAULT '1' COMMENT '站点id',
  `nickname` varchar(50) NOT NULL COMMENT '昵称',
  `username` varchar(255) NOT NULL COMMENT '用户名',
  `mobile` varchar(11) NOT NULL COMMENT '联系方式',
  `email` varchar(50) NOT NULL,
  `content` varchar(255) NOT NULL COMMENT '建议信息',
  `recont` varchar(255) NOT NULL COMMENT '回复内容',
  `ip` char(20) NOT NULL COMMENT '留言IP',
  `orderid` int(10) NOT NULL COMMENT '排序',
  `posttime` int(10) unsigned NOT NULL COMMENT '更新时间',
  `checkinfo` smallint(5) NOT NULL DEFAULT '1' COMMENT '是否审核 1=显示 0=不显示',
  `pname` varchar(50) NOT NULL,
  `pnum` int(8) NOT NULL,
  `address` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=678 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_message`
-- -----------------------------
INSERT INTO `sh_message` VALUES ('674', '1', '', 'TannerAboth', '86425797884', 'cicicoco321@163.com', 'Acai Berry - Why Is Acai Berry Supplement Great For You? \r\nIs the product certified eco-friendly? There are many copycat companies seeing that are creating products which usually are low in quality certainly not use the most beneficial process of extracti', '', '185.94.193.75', '3', '1515489863', '1', '', '0', '');
INSERT INTO `sh_message` VALUES ('675', '7', '', 'TannerAboth2', '86425797884', 'cicicoco321@163.com', 'Acai Berry - Why Is Acai Berry Supplement Great For You? \r\nIs the product certified eco-friendly? There are many copycat companies seeing that are creating products which usually are low in quality certainly not use the most beneficial process of extracti', '', '185.94.193.75', '1', '1515489863', '1', '', '0', '');

-- -----------------------------
-- Table structure for `sh_module`
-- -----------------------------
DROP TABLE IF EXISTS `sh_module`;
CREATE TABLE `sh_module` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(200) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `listfields` varchar(255) NOT NULL DEFAULT '',
  `orderid` smallint(3) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_module`
-- -----------------------------
INSERT INTO `sh_module` VALUES ('25', '图片模型', 'picurl', '图片模型', '0', '0', '', '3', '1');
INSERT INTO `sh_module` VALUES ('24', '文章模型', 'news', '文章模型', '0', '0', '', '2', '1');
INSERT INTO `sh_module` VALUES ('26', '单页模型', 'page', '单页模型', '0', '0', '', '1', '1');
INSERT INTO `sh_module` VALUES ('22', '测试1', 'test1', '测试1', '0', '0', '', '4', '1');

-- -----------------------------
-- Table structure for `sh_news`
-- -----------------------------
DROP TABLE IF EXISTS `sh_news`;
CREATE TABLE `sh_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `catid` smallint(5) unsigned NOT NULL COMMENT '所属栏目id',
  `title` varchar(80) NOT NULL COMMENT '标题',
  `flag` varchar(30) NOT NULL COMMENT '属性',
  `source` varchar(50) NOT NULL COMMENT '文章来源',
  `author` varchar(50) NOT NULL COMMENT '作者编辑',
  `linkurl` varchar(255) NOT NULL COMMENT '跳转链接',
  `keywords` varchar(50) NOT NULL COMMENT '关键词',
  `description` mediumtext NOT NULL COMMENT '摘要',
  `content` text NOT NULL COMMENT '详细内容',
  `picurl` varchar(100) NOT NULL COMMENT '缩略图片',
  `picarr` text NOT NULL COMMENT '组图',
  `hits` mediumint(8) unsigned NOT NULL COMMENT '点击次数',
  `orderid` int(10) unsigned NOT NULL COMMENT '排列排序',
  `posttime` int(10) NOT NULL COMMENT '更新时间',
  `checkinfo` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `delstate` set('true') NOT NULL DEFAULT '' COMMENT '删除状态',
  `deltime` int(10) unsigned NOT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_news`
-- -----------------------------
INSERT INTO `sh_news` VALUES ('1', '1', '75', '1111', '', '', '', '', '', '', '<p>222</p>', '/uploads/20180103/e7fe8b74c09d7b83c1d4301ab5ee134e.jpg', 'a:2:{i:0;s:69:\"/uploads/20180103/c911b719661e5fa14d38ec165e1a5101.jpg,dcerweima2.jpg\";i:1;s:63:\"/uploads/20180103/ec21a28478e83c1fce44e48eee923921.jpg,PC_A.jpg\";}', '295', '1', '1519876145', '1', '', '0');
INSERT INTO `sh_news` VALUES ('2', '1', '75', '222', '', '', '', '', '', '', '', '', 'a:2:{i:0;s:76:\"/uploads/20180103/140cd8d7e521936d443eb57093d94b47.jpg,Body-banner-kv_PC.jpg\";i:1;s:66:\"/uploads/20180103/01df51ea98fee4d7c2ff9012d6afe7c7.jpg,adbox-d.jpg\";}', '261', '2', '1519880204', '1', '', '0');

-- -----------------------------
-- Table structure for `sh_page`
-- -----------------------------
DROP TABLE IF EXISTS `sh_page`;
CREATE TABLE `sh_page` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `catid` smallint(5) unsigned NOT NULL COMMENT '所属栏目id',
  `title` varchar(80) NOT NULL COMMENT '标题',
  `linkurl` varchar(255) NOT NULL COMMENT '跳转链接',
  `content` text NOT NULL COMMENT '详细内容',
  `hits` mediumint(8) unsigned NOT NULL COMMENT '点击次数',
  `orderid` int(10) unsigned NOT NULL COMMENT '排列排序',
  `posttime` int(10) NOT NULL COMMENT '更新时间',
  `checkinfo` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `picurl` varchar(80) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_page`
-- -----------------------------
INSERT INTO `sh_page` VALUES ('1', '1', '78', '单章1', 'http://sccz.hzwzjs.net/', '<p>222</p>', '28911', '1', '1519874371', '1', '');
INSERT INTO `sh_page` VALUES ('2', '1', '8', '11', '', '', '0', '0', '0', '1', '');

-- -----------------------------
-- Table structure for `sh_picurl`
-- -----------------------------
DROP TABLE IF EXISTS `sh_picurl`;
CREATE TABLE `sh_picurl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `catid` smallint(5) unsigned NOT NULL COMMENT '所属栏目id',
  `title` varchar(80) NOT NULL COMMENT '标题',
  `flag` varchar(30) NOT NULL COMMENT '属性',
  `source` varchar(50) NOT NULL COMMENT '文章来源',
  `author` varchar(50) NOT NULL COMMENT '作者编辑',
  `linkurl` varchar(255) NOT NULL COMMENT '跳转链接',
  `keywords` varchar(50) NOT NULL COMMENT '关键词',
  `description` mediumtext NOT NULL COMMENT '摘要',
  `content` text NOT NULL COMMENT '详细内容',
  `picurl` varchar(100) NOT NULL COMMENT '缩略图片',
  `picarr` text NOT NULL COMMENT '组图',
  `hits` mediumint(8) unsigned NOT NULL COMMENT '点击次数',
  `orderid` int(10) unsigned NOT NULL COMMENT '排列排序',
  `posttime` int(10) NOT NULL COMMENT '更新时间',
  `checkinfo` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `delstate` set('true') NOT NULL DEFAULT '' COMMENT '删除状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_picurl`
-- -----------------------------
INSERT INTO `sh_picurl` VALUES ('1', '1', '76', '1111', '', '', '', '', '', '', '', '', 'a:2:{i:0;s:69:\"/uploads/20171229/b271e8f72f047e940613d53cb6d0319f.png,1514530854.png\";i:1;s:76:\"/uploads/20171229/cad7a25123173a48ca748af4994f7d69.png,2017-12-29_145527.png\";}', '227', '1', '1514950612', '1', '');
INSERT INTO `sh_picurl` VALUES ('2', '1', '0', '1111', '', '', '', '', '', '', '', '', 'a:2:{i:0;s:69:\"/uploads/20171229/b271e8f72f047e940613d53cb6d0319f.png,1514530854.png\";i:1;s:76:\"/uploads/20171229/cad7a25123173a48ca748af4994f7d69.png,2017-12-29_145527.png\";}', '227', '1', '1514950283', '1', '');
INSERT INTO `sh_picurl` VALUES ('4', '7', '76', '1111', '', '浙江省山东商会官方网站', 'saihucms', 'http://sccz.hzwzjs.net/', '爱情 / 虐恋 / 总裁', '', '<p>4444</p>', '/uploads/20180104/a1aa2be0c6c16e3ae52a8d4cfb3e4612.jpg', 'a:2:{i:0;s:66:\"/uploads/20180104/1393bf25a7b615b57cf93806f22d0143.jpg,adbox-c.jpg\";i:1;s:63:\"/uploads/20180104/0e5c9607bd086400b32373b84688be00.jpg,PC_A.jpg\";}', '168', '2', '1522567473', '1', '');

-- -----------------------------
-- Table structure for `sh_postmode`
-- -----------------------------
DROP TABLE IF EXISTS `sh_postmode`;
CREATE TABLE `sh_postmode` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '配送方式id',
  `classname` varchar(30) NOT NULL COMMENT '配送方式',
  `postprice` varchar(10) NOT NULL COMMENT '配送价格',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_postmode`
-- -----------------------------
INSERT INTO `sh_postmode` VALUES ('1', '申通', '15', '1', 'true');
INSERT INTO `sh_postmode` VALUES ('2', '中通', '15', '2', 'true');
INSERT INTO `sh_postmode` VALUES ('3', '圆通', '15', '3', 'true');
INSERT INTO `sh_postmode` VALUES ('4', '顺丰', '22', '4', 'true');
INSERT INTO `sh_postmode` VALUES ('5', 'EMS', '20', '5', 'true');

-- -----------------------------
-- Table structure for `sh_site`
-- -----------------------------
DROP TABLE IF EXISTS `sh_site`;
CREATE TABLE `sh_site` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '站点ID',
  `sitename` varchar(30) NOT NULL COMMENT '站点名称',
  `sitekey` varchar(30) NOT NULL COMMENT '站点标识',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_site`
-- -----------------------------
INSERT INTO `sh_site` VALUES ('1', '中文版', 'zh_CN');
INSERT INTO `sh_site` VALUES ('7', '英文站', 'en_US');

-- -----------------------------
-- Table structure for `sh_soft`
-- -----------------------------
DROP TABLE IF EXISTS `sh_soft`;
CREATE TABLE `sh_soft` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '软件信息id',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `classid` smallint(5) unsigned NOT NULL COMMENT '所属栏目id',
  `parentid` smallint(5) unsigned NOT NULL COMMENT '所属栏目上级id',
  `parentstr` varchar(80) NOT NULL COMMENT '所属栏目上级id字符串',
  `mainid` smallint(5) NOT NULL COMMENT '二级类别id',
  `mainpid` smallint(5) NOT NULL COMMENT '二级类别父id',
  `mainpstr` varchar(80) NOT NULL COMMENT '二级累呗父id字符串',
  `title` varchar(80) NOT NULL COMMENT '标题',
  `colorval` char(10) NOT NULL COMMENT '字体颜色',
  `boldval` char(10) NOT NULL COMMENT '字体加粗',
  `flag` varchar(30) NOT NULL COMMENT '属性',
  `filetype` char(4) NOT NULL COMMENT '文件类型',
  `softtype` char(10) NOT NULL COMMENT '软件类型',
  `language` char(10) NOT NULL COMMENT '界面语言',
  `accredit` char(10) NOT NULL COMMENT '授权方式',
  `softsize` varchar(10) NOT NULL COMMENT '软件大小',
  `unit` char(4) NOT NULL COMMENT '软件大小单位',
  `runos` varchar(50) NOT NULL COMMENT '运行环境',
  `website` varchar(255) NOT NULL COMMENT '官方网站',
  `demourl` varchar(255) NOT NULL COMMENT '演示地址',
  `dlurl` varchar(255) NOT NULL COMMENT '下载地址',
  `source` varchar(50) NOT NULL COMMENT '文章来源',
  `author` varchar(50) NOT NULL COMMENT '作者编辑',
  `linkurl` varchar(255) NOT NULL COMMENT '跳转链接',
  `keywords` varchar(50) NOT NULL COMMENT '关键字',
  `description` varchar(255) NOT NULL COMMENT '描述',
  `content` mediumtext NOT NULL COMMENT '内容',
  `picurl` varchar(100) NOT NULL COMMENT '缩略图片',
  `picarr` text NOT NULL COMMENT '组图',
  `hits` mediumint(8) unsigned NOT NULL COMMENT '点击次数',
  `orderid` int(10) unsigned NOT NULL COMMENT '排列排序',
  `posttime` int(10) NOT NULL COMMENT '更新时间',
  `checkinfo` enum('true','false') NOT NULL COMMENT '审核状态',
  `delstate` set('true') NOT NULL COMMENT '删除状态',
  `deltime` int(10) unsigned NOT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_soft`
-- -----------------------------
INSERT INTO `sh_soft` VALUES ('6', '1', '185', '2', '0,2,', '-1', '-1', '', '1111111111', '', '', '', '.exe', '国产软件', '简体中文', '共享软件', '1', 'MB', 'Win7/WinXP/WinNT', '', '', 'uploads/soft/20160829/1472449968.zip', '', 'saihucms', '', '', 'qqqqqq', '', 'uploads/image/20160829/1472456740.png', '', '178', '1', '1472449034', 'true', 'true', '1474871616');

-- -----------------------------
-- Table structure for `sh_sysevent`
-- -----------------------------
DROP TABLE IF EXISTS `sh_sysevent`;
CREATE TABLE `sh_sysevent` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uname` varchar(30) NOT NULL COMMENT '用户名',
  `siteid` tinyint(1) unsigned NOT NULL COMMENT '站点id',
  `model` varchar(30) NOT NULL COMMENT '操作模块',
  `classid` int(10) unsigned NOT NULL COMMENT '栏目id',
  `action` varchar(10) NOT NULL COMMENT '执行操作',
  `posttime` int(10) NOT NULL COMMENT '操作时间',
  `ip` varchar(20) NOT NULL COMMENT '操作ip',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6779 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `sh_test1`
-- -----------------------------
DROP TABLE IF EXISTS `sh_test1`;
CREATE TABLE `sh_test1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `catid` smallint(5) NOT NULL,
  `title` varchar(80) NOT NULL COMMENT '标题',
  `flag` varchar(30) NOT NULL COMMENT '属性',
  `source` varchar(50) NOT NULL COMMENT '文章来源',
  `author` varchar(50) NOT NULL COMMENT '作者编辑',
  `linkurl` varchar(255) NOT NULL COMMENT '跳转链接',
  `keywords` varchar(50) NOT NULL COMMENT '关键词',
  `description` mediumtext NOT NULL COMMENT '摘要',
  `hits` mediumint(8) unsigned NOT NULL COMMENT '点击次数',
  `orderid` int(10) unsigned NOT NULL COMMENT '排列排序',
  `posttime` int(10) NOT NULL COMMENT '更新时间',
  `checkinfo` tinyint(3) NOT NULL COMMENT '审核状态',
  `delstate` set('true') NOT NULL DEFAULT '' COMMENT '删除状态',
  `deltime` int(10) unsigned NOT NULL COMMENT '删除时间',
  `picurl` varchar(80) NOT NULL DEFAULT '',
  `picarr` mediumtext NOT NULL,
  `content` text NOT NULL,
  `content2` text NOT NULL,
  `fuxuan` varchar(255) NOT NULL DEFAULT '',
  `shuzi` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `riqi` int(11) unsigned NOT NULL DEFAULT '0',
  `duoxuan` varchar(255) NOT NULL DEFAULT '',
  `danxia` int(10) unsigned NOT NULL DEFAULT '0',
  `lian` varchar(80) NOT NULL DEFAULT '',
  `wenjian` varchar(80) NOT NULL DEFAULT '',
  `picarr2` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_test1`
-- -----------------------------
INSERT INTO `sh_test1` VALUES ('2', '1', '71', '测试1', '', '浙江省山东商会官方网站', 'saihucms', 'http://sccz.hzwzjs.net/', '爱情 / 虐恋 / 总裁', '2222', '105', '4', '1514432678', '1', '', '0', '/uploads/20171228/5685906dfc0f3b1d68f4adbc88089d95.jpg', 'a:3:{i:0;s:61:\"/uploads/20171228/5bb2e1a47d0ac8ed0f8d9483dac4a045.jpg,111111\";i:1;s:59:\"/uploads/20171228/6130fd9276e97218de76a0f6b2a82226.jpg,2222\";i:2;s:60:\"/uploads/20171228/c527f50f5c12fb7614337e66ec1282f3.jpg,33333\";}', '333', '<p>4444</p>', '2,3', '4.66', '1514563200', '1,2,3', '2', 'a:3:{s:4:\"prov\";s:6:\"湖南\";s:4:\"city\";s:6:\"长沙\";s:4:\"dist\";s:9:\"天心区\";}', '/uploads/20171228/48900208b59f50609ae636cff3108638.zip', 'a:3:{i:0;s:58:\"/uploads/20171228/1eded6ab2dbd2df2ae9e444e793887e3.jpg,777\";i:1;s:58:\"/uploads/20171228/22165ab4048ee93bd2ae396435fbf88d.jpg,888\";i:2;s:58:\"/uploads/20171228/d873c763dc817da305413bc2684a1295.jpg,999\";}');
INSERT INTO `sh_test1` VALUES ('3', '1', '71', '测试2', '', '', '', '', '', '', '215', '13', '1514452938', '1', '', '0', '', '', '', '', '1,2,3,4', '0.00', '0', '', '0', 'a:3:{s:4:\"prov\";s:6:\"广东\";s:4:\"city\";s:6:\"广州\";s:4:\"dist\";s:9:\"海珠区\";}', '', '');
INSERT INTO `sh_test1` VALUES ('13', '1', '71', '测试12', '', '浙江省山东商会官方网站', 'saihucms', 'http://sccz.hzwzjs.net/', '爱情 / 虐恋 / 总裁', '2222', '105', '17', '1514432678', '1', '', '0', '/uploads/20171228/5685906dfc0f3b1d68f4adbc88089d95.jpg', 'a:3:{i:0;s:61:\"/uploads/20171228/5bb2e1a47d0ac8ed0f8d9483dac4a045.jpg,111111\";i:1;s:59:\"/uploads/20171228/6130fd9276e97218de76a0f6b2a82226.jpg,2222\";i:2;s:60:\"/uploads/20171228/c527f50f5c12fb7614337e66ec1282f3.jpg,33333\";}', '333', '<p>4444</p>', '2,3', '4.66', '1514563200', '1,2,3', '2', 'a:3:{s:4:\"prov\";s:6:\"湖南\";s:4:\"city\";s:6:\"长沙\";s:4:\"dist\";s:9:\"天心区\";}', '/uploads/20171228/48900208b59f50609ae636cff3108638.zip', 'a:3:{i:0;s:58:\"/uploads/20171228/1eded6ab2dbd2df2ae9e444e793887e3.jpg,777\";i:1;s:58:\"/uploads/20171228/22165ab4048ee93bd2ae396435fbf88d.jpg,888\";i:2;s:58:\"/uploads/20171228/d873c763dc817da305413bc2684a1295.jpg,999\";}');
INSERT INTO `sh_test1` VALUES ('5', '1', '71', '测试4', '', '浙江省山东商会官方网站', 'saihucms', 'http://sccz.hzwzjs.net/', '爱情 / 虐恋 / 总裁', '2222', '105', '7', '1514432678', '1', '', '0', '/uploads/20171228/5685906dfc0f3b1d68f4adbc88089d95.jpg', 'a:3:{i:0;s:61:\"/uploads/20171228/5bb2e1a47d0ac8ed0f8d9483dac4a045.jpg,111111\";i:1;s:59:\"/uploads/20171228/6130fd9276e97218de76a0f6b2a82226.jpg,2222\";i:2;s:60:\"/uploads/20171228/c527f50f5c12fb7614337e66ec1282f3.jpg,33333\";}', '333', '<p>4444</p>', '2,3', '4.66', '1514563200', '1,2,3', '2', 'a:3:{s:4:\"prov\";s:6:\"湖南\";s:4:\"city\";s:6:\"长沙\";s:4:\"dist\";s:9:\"天心区\";}', '/uploads/20171228/48900208b59f50609ae636cff3108638.zip', 'a:3:{i:0;s:58:\"/uploads/20171228/1eded6ab2dbd2df2ae9e444e793887e3.jpg,777\";i:1;s:58:\"/uploads/20171228/22165ab4048ee93bd2ae396435fbf88d.jpg,888\";i:2;s:58:\"/uploads/20171228/d873c763dc817da305413bc2684a1295.jpg,999\";}');
INSERT INTO `sh_test1` VALUES ('6', '1', '71', '测试5', '', '浙江省山东商会官方网站', 'saihucms', 'http://sccz.hzwzjs.net/', '爱情 / 虐恋 / 总裁', '2222', '105', '8', '1514432678', '1', '', '0', '/uploads/20171228/5685906dfc0f3b1d68f4adbc88089d95.jpg', 'a:3:{i:0;s:61:\"/uploads/20171228/5bb2e1a47d0ac8ed0f8d9483dac4a045.jpg,111111\";i:1;s:59:\"/uploads/20171228/6130fd9276e97218de76a0f6b2a82226.jpg,2222\";i:2;s:60:\"/uploads/20171228/c527f50f5c12fb7614337e66ec1282f3.jpg,33333\";}', '333', '<p>4444</p>', '2,3', '4.66', '1514563200', '1,2,3', '2', 'a:3:{s:4:\"prov\";s:6:\"湖南\";s:4:\"city\";s:6:\"长沙\";s:4:\"dist\";s:9:\"天心区\";}', '/uploads/20171228/48900208b59f50609ae636cff3108638.zip', 'a:3:{i:0;s:58:\"/uploads/20171228/1eded6ab2dbd2df2ae9e444e793887e3.jpg,777\";i:1;s:58:\"/uploads/20171228/22165ab4048ee93bd2ae396435fbf88d.jpg,888\";i:2;s:58:\"/uploads/20171228/d873c763dc817da305413bc2684a1295.jpg,999\";}');
INSERT INTO `sh_test1` VALUES ('7', '1', '71', '测试6', '', '浙江省山东商会官方网站', 'saihucms', 'http://sccz.hzwzjs.net/', '爱情 / 虐恋 / 总裁', '2222', '105', '9', '1514432678', '1', '', '0', '/uploads/20171228/5685906dfc0f3b1d68f4adbc88089d95.jpg', 'a:3:{i:0;s:61:\"/uploads/20171228/5bb2e1a47d0ac8ed0f8d9483dac4a045.jpg,111111\";i:1;s:59:\"/uploads/20171228/6130fd9276e97218de76a0f6b2a82226.jpg,2222\";i:2;s:60:\"/uploads/20171228/c527f50f5c12fb7614337e66ec1282f3.jpg,33333\";}', '333', '<p>4444</p>', '2,3', '4.66', '1514563200', '1,2,3', '2', 'a:3:{s:4:\"prov\";s:6:\"湖南\";s:4:\"city\";s:6:\"长沙\";s:4:\"dist\";s:9:\"天心区\";}', '/uploads/20171228/48900208b59f50609ae636cff3108638.zip', 'a:3:{i:0;s:58:\"/uploads/20171228/1eded6ab2dbd2df2ae9e444e793887e3.jpg,777\";i:1;s:58:\"/uploads/20171228/22165ab4048ee93bd2ae396435fbf88d.jpg,888\";i:2;s:58:\"/uploads/20171228/d873c763dc817da305413bc2684a1295.jpg,999\";}');
INSERT INTO `sh_test1` VALUES ('8', '1', '71', '测试7', '', '浙江省山东商会官方网站', 'saihucms', 'http://sccz.hzwzjs.net/', '爱情 / 虐恋 / 总裁', '2222', '105', '10', '1514432678', '1', '', '0', '/uploads/20171228/5685906dfc0f3b1d68f4adbc88089d95.jpg', 'a:3:{i:0;s:61:\"/uploads/20171228/5bb2e1a47d0ac8ed0f8d9483dac4a045.jpg,111111\";i:1;s:59:\"/uploads/20171228/6130fd9276e97218de76a0f6b2a82226.jpg,2222\";i:2;s:60:\"/uploads/20171228/c527f50f5c12fb7614337e66ec1282f3.jpg,33333\";}', '333', '<p>4444</p>', '2,3', '4.66', '1514563200', '1,2,3', '2', 'a:3:{s:4:\"prov\";s:6:\"湖南\";s:4:\"city\";s:6:\"长沙\";s:4:\"dist\";s:9:\"天心区\";}', '/uploads/20171228/48900208b59f50609ae636cff3108638.zip', 'a:3:{i:0;s:58:\"/uploads/20171228/1eded6ab2dbd2df2ae9e444e793887e3.jpg,777\";i:1;s:58:\"/uploads/20171228/22165ab4048ee93bd2ae396435fbf88d.jpg,888\";i:2;s:58:\"/uploads/20171228/d873c763dc817da305413bc2684a1295.jpg,999\";}');
INSERT INTO `sh_test1` VALUES ('9', '1', '71', '测试8', '', '浙江省山东商会官方网站', 'saihucms', 'http://sccz.hzwzjs.net/', '爱情 / 虐恋 / 总裁', '2222', '105', '11', '1514432678', '1', '', '0', '/uploads/20171228/5685906dfc0f3b1d68f4adbc88089d95.jpg', 'a:3:{i:0;s:61:\"/uploads/20171228/5bb2e1a47d0ac8ed0f8d9483dac4a045.jpg,111111\";i:1;s:59:\"/uploads/20171228/6130fd9276e97218de76a0f6b2a82226.jpg,2222\";i:2;s:60:\"/uploads/20171228/c527f50f5c12fb7614337e66ec1282f3.jpg,33333\";}', '333', '<p>4444</p>', '2,3', '4.66', '1514563200', '1,2,3', '2', 'a:3:{s:4:\"prov\";s:6:\"湖南\";s:4:\"city\";s:6:\"长沙\";s:4:\"dist\";s:9:\"天心区\";}', '/uploads/20171228/48900208b59f50609ae636cff3108638.zip', 'a:3:{i:0;s:58:\"/uploads/20171228/1eded6ab2dbd2df2ae9e444e793887e3.jpg,777\";i:1;s:58:\"/uploads/20171228/22165ab4048ee93bd2ae396435fbf88d.jpg,888\";i:2;s:58:\"/uploads/20171228/d873c763dc817da305413bc2684a1295.jpg,999\";}');
INSERT INTO `sh_test1` VALUES ('10', '1', '71', '测试9', '', '浙江省山东商会官方网站', 'saihucms', 'http://sccz.hzwzjs.net/', '爱情 / 虐恋 / 总裁', '2222', '105', '12', '1514432678', '1', '', '0', '/uploads/20171228/5685906dfc0f3b1d68f4adbc88089d95.jpg', 'a:3:{i:0;s:61:\"/uploads/20171228/5bb2e1a47d0ac8ed0f8d9483dac4a045.jpg,111111\";i:1;s:59:\"/uploads/20171228/6130fd9276e97218de76a0f6b2a82226.jpg,2222\";i:2;s:60:\"/uploads/20171228/c527f50f5c12fb7614337e66ec1282f3.jpg,33333\";}', '333', '<p>4444</p>', '2,3', '4.66', '1514563200', '1,2,3', '2', 'a:3:{s:4:\"prov\";s:6:\"湖南\";s:4:\"city\";s:6:\"长沙\";s:4:\"dist\";s:9:\"天心区\";}', '/uploads/20171228/48900208b59f50609ae636cff3108638.zip', 'a:3:{i:0;s:58:\"/uploads/20171228/1eded6ab2dbd2df2ae9e444e793887e3.jpg,777\";i:1;s:58:\"/uploads/20171228/22165ab4048ee93bd2ae396435fbf88d.jpg,888\";i:2;s:58:\"/uploads/20171228/d873c763dc817da305413bc2684a1295.jpg,999\";}');
INSERT INTO `sh_test1` VALUES ('11', '1', '71', '测试10', '', '浙江省山东商会官方网站', 'saihucms', 'http://sccz.hzwzjs.net/', '爱情 / 虐恋 / 总裁', '2222', '105', '16', '1514432678', '1', '', '0', '/uploads/20171228/5685906dfc0f3b1d68f4adbc88089d95.jpg', 'a:3:{i:0;s:61:\"/uploads/20171228/5bb2e1a47d0ac8ed0f8d9483dac4a045.jpg,111111\";i:1;s:59:\"/uploads/20171228/6130fd9276e97218de76a0f6b2a82226.jpg,2222\";i:2;s:60:\"/uploads/20171228/c527f50f5c12fb7614337e66ec1282f3.jpg,33333\";}', '333', '<p>4444</p>', '2,3', '4.66', '1514563200', '1,2,3', '2', 'a:3:{s:4:\"prov\";s:6:\"湖南\";s:4:\"city\";s:6:\"长沙\";s:4:\"dist\";s:9:\"天心区\";}', '/uploads/20171228/48900208b59f50609ae636cff3108638.zip', 'a:3:{i:0;s:58:\"/uploads/20171228/1eded6ab2dbd2df2ae9e444e793887e3.jpg,777\";i:1;s:58:\"/uploads/20171228/22165ab4048ee93bd2ae396435fbf88d.jpg,888\";i:2;s:58:\"/uploads/20171228/d873c763dc817da305413bc2684a1295.jpg,999\";}');
INSERT INTO `sh_test1` VALUES ('12', '1', '71', '测试11', '', '浙江省山东商会官方网站', 'saihucms', 'http://sccz.hzwzjs.net/', '爱情 / 虐恋 / 总裁', '2222', '105', '18', '1514432678', '1', '', '0', '/uploads/20171228/5685906dfc0f3b1d68f4adbc88089d95.jpg', 'a:3:{i:0;s:61:\"/uploads/20171228/5bb2e1a47d0ac8ed0f8d9483dac4a045.jpg,111111\";i:1;s:59:\"/uploads/20171228/6130fd9276e97218de76a0f6b2a82226.jpg,2222\";i:2;s:60:\"/uploads/20171228/c527f50f5c12fb7614337e66ec1282f3.jpg,33333\";}', '333', '<p>4444</p>', '2,3', '4.66', '1514563200', '1,2,3', '2', 'a:3:{s:4:\"prov\";s:6:\"湖南\";s:4:\"city\";s:6:\"长沙\";s:4:\"dist\";s:9:\"天心区\";}', '/uploads/20171228/48900208b59f50609ae636cff3108638.zip', 'a:3:{i:0;s:58:\"/uploads/20171228/1eded6ab2dbd2df2ae9e444e793887e3.jpg,777\";i:1;s:58:\"/uploads/20171228/22165ab4048ee93bd2ae396435fbf88d.jpg,888\";i:2;s:58:\"/uploads/20171228/d873c763dc817da305413bc2684a1295.jpg,999\";}');

-- -----------------------------
-- Table structure for `sh_uploads`
-- -----------------------------
DROP TABLE IF EXISTS `sh_uploads`;
CREATE TABLE `sh_uploads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL COMMENT '文件名称',
  `path` varchar(100) NOT NULL COMMENT '文件路径',
  `size` int(10) NOT NULL COMMENT '文件大小',
  `type` enum('image','soft','media') NOT NULL COMMENT '文件类型',
  `posttime` int(10) NOT NULL COMMENT '上传日期',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=848 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `sh_webconfig`
-- -----------------------------
DROP TABLE IF EXISTS `sh_webconfig`;
CREATE TABLE `sh_webconfig` (
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `varname` varchar(50) NOT NULL COMMENT '变量名称',
  `varinfo` varchar(80) NOT NULL COMMENT '参数说明',
  `vargroup` smallint(5) unsigned NOT NULL COMMENT '所属组',
  `vartype` char(10) NOT NULL COMMENT '变量类型',
  `varvalue` text NOT NULL COMMENT '变量值',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  PRIMARY KEY (`varname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_webconfig`
-- -----------------------------
INSERT INTO `sh_webconfig` VALUES ('1', 'cfg_webname', '网站名称', '0', 'string', '杭州语奥生物科技有限公司', '1');
INSERT INTO `sh_webconfig` VALUES ('1', 'cfg_weburl', '网站地址', '0', 'string', 'http://sh.yuaomed.com', '2');
INSERT INTO `sh_webconfig` VALUES ('1', 'cfg_webpath', '网站目录', '0', 'string', '', '3');
INSERT INTO `sh_webconfig` VALUES ('1', 'cfg_author', '网站作者', '0', 'string', '赛虎科技', '4');
INSERT INTO `sh_webconfig` VALUES ('1', 'cfg_generator', '程序引擎', '0', 'string', 'SaiHuCms', '5');
INSERT INTO `sh_webconfig` VALUES ('1', 'cfg_keyword', '关键字设置', '0', 'string', '语奥生物,透明质酸,医用敷料,医疗器械招商,医用耗材,生物医用材料,妇产科,', '6');
INSERT INTO `sh_webconfig` VALUES ('1', 'cfg_description', '网站描述', '0', 'bstring', '', '7');
INSERT INTO `sh_webconfig` VALUES ('7', 'cfg_switchshow_en_US', '关闭说明', '0', 'bstring', '对不起，网站维护，请稍后登陆。<br />网站维护期间对您造成的不便，请谅解！', '11');
INSERT INTO `sh_webconfig` VALUES ('7', 'cfg_webswitch_en_US', '启用站点', '0', 'bool', 'Y', '10');
INSERT INTO `sh_webconfig` VALUES ('7', 'cfg_icp_en_US', '备案编号', '0', 'string', '', '9');
INSERT INTO `sh_webconfig` VALUES ('7', 'cfg_copyright_en_US', '版权信息', '0', 'bstring', 'Copyright © 2010 - 2013 shkj.net All Rights Reserved', '8');
INSERT INTO `sh_webconfig` VALUES ('1', 'cfg_copyright', '版权信息', '0', 'bstring', '', '103');
INSERT INTO `sh_webconfig` VALUES ('1', 'cfg_telphone', '电话号码', '0', 'string', '', '101');
INSERT INTO `sh_webconfig` VALUES ('1', 'cfg_hotline', '客服热线', '0', 'string', '0571-578936361', '9');
INSERT INTO `sh_webconfig` VALUES ('1', 'cfg_icp', '备案编号', '0', 'string', '浙ICP备14013810号-1', '10');
INSERT INTO `sh_webconfig` VALUES ('1', 'cfg_webswitch', '启用站点', '0', 'bool', 'Y', '11');
INSERT INTO `sh_webconfig` VALUES ('1', 'cfg_switchshow', '关闭说明', '0', 'bstring', '', '12');
INSERT INTO `sh_webconfig` VALUES ('1', 'cfg_upload_img_type', '上传图片类型', '1', 'string', 'gif|png|jpg|bmp|jpeg', '23');
INSERT INTO `sh_webconfig` VALUES ('1', 'cfg_upload_soft_type', '上传软件类型', '1', 'string', 'zip|gz|rar|iso|doc|xls|ppt|wps|txt|docx', '24');
INSERT INTO `sh_webconfig` VALUES ('1', 'cfg_upload_media_type', '上传媒体类型', '1', 'string', 'swf|flv|mpg|mp3|rm|rmvb|wmv|wma|wav|ogg', '25');
INSERT INTO `sh_webconfig` VALUES ('1', 'cfg_max_file_size', '上传文件大小', '1', 'string', '20971520', '26');
INSERT INTO `sh_webconfig` VALUES ('1', 'cfg_address', '详细地址', '0', 'string', '中国·浙江杭州', '98');
INSERT INTO `sh_webconfig` VALUES ('1', 'cfg_fax', '公司传真', '0', 'string', '', '99');
INSERT INTO `sh_webconfig` VALUES ('1', 'cfg_email', '公司邮箱', '0', 'string', 'yuaomed@163.com', '100');
INSERT INTO `sh_webconfig` VALUES ('7', 'cfg_keyword_en_US', '关键字设置', '0', 'string', '', '6');
INSERT INTO `sh_webconfig` VALUES ('7', 'cfg_description_en_US', '网站描述', '0', 'bstring', '', '7');
INSERT INTO `sh_webconfig` VALUES ('7', 'cfg_generator_en_US', '程序引擎', '0', 'string', 'saihuCMS', '5');
INSERT INTO `sh_webconfig` VALUES ('7', 'cfg_webname_en_US', '网站名称', '0', 'string', '实验英文站', '1');
INSERT INTO `sh_webconfig` VALUES ('7', 'cfg_weburl_en_US', '网站地址', '0', 'string', 'http://sh.com', '2');
INSERT INTO `sh_webconfig` VALUES ('7', 'cfg_webpath_en_US', '网站目录', '0', 'string', 'http://sh.com/yuaomed.com/m', '3');
INSERT INTO `sh_webconfig` VALUES ('7', 'cfg_author_en_US', '网站作者', '0', 'string', 'saihuCMS Team', '4');

-- -----------------------------
-- Table structure for `sh_weblink`
-- -----------------------------
DROP TABLE IF EXISTS `sh_weblink`;
CREATE TABLE `sh_weblink` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '友情链接id',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `classid` smallint(5) unsigned NOT NULL COMMENT '所属类别id',
  `parentid` smallint(5) unsigned NOT NULL COMMENT '所属类别父id',
  `parentstr` varchar(80) NOT NULL COMMENT '所属类别父id字符串',
  `webname` varchar(30) NOT NULL COMMENT '网站名称',
  `webnote` varchar(200) NOT NULL COMMENT '网站描述',
  `picurl` varchar(100) NOT NULL COMMENT '缩略图片',
  `linkurl` varchar(255) NOT NULL COMMENT '跳转链接',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列排序',
  `posttime` int(10) unsigned NOT NULL COMMENT '更新时间',
  `checkinfo` smallint(5) NOT NULL COMMENT '审核状态 1=显示 0=不显示',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_weblink`
-- -----------------------------
INSERT INTO `sh_weblink` VALUES ('45', '1', '3', '0', '', '222', 'yy', '/uploads/20180109/01016d18485af4b5ac77ea1ad5694576.png', 'http://sccz.hzwzjs.net/', '4', '1515467408', '1');
INSERT INTO `sh_weblink` VALUES ('43', '1', '3', '0', '', '1111', '方法', '/uploads/20180109/ba5efa1526a077bc04266fac4be076e1.png', 'http://sccz.hzwzjs.net/', '2', '1535769297', '1');
INSERT INTO `sh_weblink` VALUES ('42', '1', '3', '0', '', '测试网址名3', '呵呵', '/uploads/20180109/b9514448f9679c74446b1d6c20067695.png', 'http://sccz.hzwzjs.net/', '1', '1535768586', '1');
INSERT INTO `sh_weblink` VALUES ('44', '1', '3', '0', '', '测试网址名2', '呵呵', '/uploads/20180109/b9514448f9679c74446b1d6c20067695.png', 'http://sccz.hzwzjs.net/', '3', '1535768586', '1');
INSERT INTO `sh_weblink` VALUES ('46', '1', '3', '0', '', '1111', '111', '/uploads/20180109/7a58a6a5ed06218a3899412be45ef4d7.png', 'http://sccz.hzwzjs.net/', '5', '1535786927', '1');
INSERT INTO `sh_weblink` VALUES ('47', '1', '3', '0', '', '实验英文站', '11', '/uploads/20180109/e6e1fb2f256cc771ff365c841b97f697.png', 'http://sccz.hzwzjs.net/', '6', '1535787547', '1');
INSERT INTO `sh_weblink` VALUES ('48', '7', '17', '0', '', '实验英文站', '111', '', 'http://sccz.hzwzjs.net/', '7', '1538357607', '1');

-- -----------------------------
-- Table structure for `sh_weblinktype`
-- -----------------------------
DROP TABLE IF EXISTS `sh_weblinktype`;
CREATE TABLE `sh_weblinktype` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '友情链接类型id',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '站点id',
  `parentid` smallint(5) unsigned NOT NULL COMMENT '类别父id',
  `parentstr` varchar(50) NOT NULL COMMENT '类别父id字符串',
  `classname` varchar(30) NOT NULL COMMENT '类别名称',
  `orderid` smallint(5) unsigned NOT NULL COMMENT '排列顺序',
  `checkinfo` smallint(6) NOT NULL DEFAULT '1' COMMENT '审核状态 1=显示，0=不显示',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_weblinktype`
-- -----------------------------
INSERT INTO `sh_weblinktype` VALUES ('3', '1', '0', '0', '友情链接', '3', '1');
INSERT INTO `sh_weblinktype` VALUES ('10', '1', '3', '0,3', '新闻资讯', '4', '1');
INSERT INTO `sh_weblinktype` VALUES ('17', '7', '0', '0', '222', '5', '1');
INSERT INTO `sh_weblinktype` VALUES ('18', '7', '17', '0,17', '333', '6', '1');

-- -----------------------------
-- Table structure for `sh_wx_config`
-- -----------------------------
DROP TABLE IF EXISTS `sh_wx_config`;
CREATE TABLE `sh_wx_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `AppID` varchar(50) NOT NULL,
  `AppSecret` varchar(100) NOT NULL,
  `Token` varchar(100) NOT NULL,
  `EncodingAESKey` varchar(100) NOT NULL,
  `guanzhu` text NOT NULL COMMENT '关注回复',
  `moren` text NOT NULL COMMENT '默认回复',
  `server_address` varchar(100) NOT NULL COMMENT '接入地址',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_wx_config`
-- -----------------------------
INSERT INTO `sh_wx_config` VALUES ('1', 'wx559b03314b8907b4', '17368653ff8a2ba8e91fb7ed91fa7b69', 'tangyin', 'nozKLm7jbHiJGLu2diYBGzPY8pGdNobX9kNevGxyaQB', '欢迎您', '请输入 对 的参数', 'http://tangyan.hzwzjs.net/admin/wechat/wx_sample');

-- -----------------------------
-- Table structure for `sh_wx_menu`
-- -----------------------------
DROP TABLE IF EXISTS `sh_wx_menu`;
CREATE TABLE `sh_wx_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `open` tinyint(1) DEFAULT '1' COMMENT '状态',
  `pid` int(11) DEFAULT '0' COMMENT '上级菜单',
  `name` varchar(50) NOT NULL COMMENT '名称',
  `orderid` int(5) DEFAULT '0' COMMENT '排序',
  `type` varchar(20) DEFAULT '' COMMENT 'view/click',
  `value` varchar(255) DEFAULT NULL COMMENT 'value',
  `token` varchar(50) NOT NULL COMMENT 'token',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_wx_menu`
-- -----------------------------
INSERT INTO `sh_wx_menu` VALUES ('1', '1', '0', '官网', '1', 'view', 'http://www.cltphp.com', 'eesops1462769263');
INSERT INTO `sh_wx_menu` VALUES ('2', '1', '0', '文档', '2', 'click', '文档', 'eesops1462769263');
INSERT INTO `sh_wx_menu` VALUES ('3', '1', '2', '操作文档', '3', 'view', 'https://www.kancloud.cn/chichu/cltphp', 'eesops1462769263');
INSERT INTO `sh_wx_menu` VALUES ('33', '1', '2', '开发文档', '4', 'view', 'http://www.kancloud.cn/chichu/cltphp', '');
INSERT INTO `sh_wx_menu` VALUES ('38', '1', '0', '测试', '5', 'view', 'http://www.cltphp.com', '');
INSERT INTO `sh_wx_menu` VALUES ('39', '1', '2', '111', '6', 'view', 'http://www.cltphp.com', '');
INSERT INTO `sh_wx_menu` VALUES ('40', '1', '2', '222', '7', 'view', 'http://www.cltphp.com', '');

-- -----------------------------
-- Table structure for `sh_wx_reply`
-- -----------------------------
DROP TABLE IF EXISTS `sh_wx_reply`;
CREATE TABLE `sh_wx_reply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keyword` varchar(20) NOT NULL COMMENT '关键字',
  `msgType` varchar(10) NOT NULL COMMENT '类型 text=文本',
  `posttime` int(11) NOT NULL COMMENT '创建时间',
  `content` text NOT NULL COMMENT '文本内容',
  `open` int(5) NOT NULL DEFAULT '1' COMMENT '1=显示，0=不显示',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_wx_reply`
-- -----------------------------
INSERT INTO `sh_wx_reply` VALUES ('1', '6662', 'text', '1516067105', '范德萨发的说法的的订单', '1');
INSERT INTO `sh_wx_reply` VALUES ('7', '11', 'images', '1516090247', '', '1');
INSERT INTO `sh_wx_reply` VALUES ('4', '111', 'image', '1516086113', '', '1');

-- -----------------------------
-- Table structure for `sh_wx_reply_content`
-- -----------------------------
DROP TABLE IF EXISTS `sh_wx_reply_content`;
CREATE TABLE `sh_wx_reply_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reply_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL COMMENT '标题',
  `description` varchar(255) NOT NULL COMMENT '简介',
  `picurl` varchar(100) NOT NULL COMMENT '图片地址',
  `url` varchar(100) NOT NULL COMMENT '链接',
  `open` int(11) NOT NULL DEFAULT '1' COMMENT '1=开启，0=关闭',
  `posttime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `sh_wx_reply_content`
-- -----------------------------
INSERT INTO `sh_wx_reply_content` VALUES ('1', '4', '2224444', '发方法', '/uploads/20180116/19fd5732da3b3200150024cbc563563f.png', 'http://design.nabel.cc/', '1', '0');
INSERT INTO `sh_wx_reply_content` VALUES ('2', '5', '1111111', '请问呜呜', '/uploads/20180116/90793e2160ea01a2bdb951fa506ad410.png', '5555', '1', '0');
INSERT INTO `sh_wx_reply_content` VALUES ('6', '7', '测试图2', '发的发的发的发的', '/uploads/20180116/748712535dc2217d552d394d8ffa21ee.png', 'http://design.nabel.cc/', '1', '1516092669');
INSERT INTO `sh_wx_reply_content` VALUES ('8', '7', '范德萨范德萨范德萨', '范德萨范德萨发的疏飞', '/uploads/20180116/41333b8274a96617073013e99fdfd65f.png', '', '1', '1516094214');
INSERT INTO `sh_wx_reply_content` VALUES ('9', '7', '发得分得分', '发的发的发的发的', '/uploads/20180116/e04b075bce1d5f7695424aac6c9fba3c.png', '发的发的发的', '1', '1516094234');
INSERT INTO `sh_wx_reply_content` VALUES ('10', '7', '发的发生发到', '发的发的发的发的发的', '/uploads/20180116/0df74f1edf82b1b2152f7a2ea8a2ca9a.png', '', '1', '1516094266');
INSERT INTO `sh_wx_reply_content` VALUES ('11', '7', '发的发的发的规范广告', '规范撒范德萨发生', '/uploads/20180116/7f77d46da35bbf4079a3e2e7ea04ed09.png', '', '1', '1516094280');
INSERT INTO `sh_wx_reply_content` VALUES ('12', '7', '过分的话热热热', '打三分无法', '/uploads/20180116/0e13b44b6dd85f04b1af5c0a5d4e701c.png', '热温热', '1', '1516094295');
INSERT INTO `sh_wx_reply_content` VALUES ('13', '7', '偶ikyuggfg', 'vfdsgdf', '/uploads/20180116/e802c39511f3e07b039f0fb6566697e8.png', '范德萨范德萨范德萨范德萨', '1', '1516094320');
INSERT INTO `sh_wx_reply_content` VALUES ('14', '7', '发生的发生地方都是', '范德萨范德萨范德萨', '/uploads/20180116/3a619db8d3cb2bc01da1bba6eca5d654.png', '', '1', '1516094679');
